/*
 * IMPORTANT : JS file no longer used !
 */

var fileApiService = new FileApiService();

function getImage(){
    $("#get-image-container").empty();
    $("#get-image-container").append("<img style=\"width:100px;\" src="+baseFileApiUrl+"/file/book-cover.jpg>")
}


/* callback functions */
function onGetHttpDone(result){
    var html = "<table><tr><th>filename</th><th>file size</th><th>last modified</th>";
    var prefix = "foo4212/";
    for(var i=0; i<result.length; i++){
        html+="<tr><td>";
        html+=(result[i][0]==prefix)? result[i][0].replace(prefix, "..") : result[i][0].replace(prefix, "");
        html+="</td><td>";
        html+=result[i][1];
        html+="</td><td>";
        html+=result[i][2];
        html+="</td></tr>";
    }
    html+="<table>"
    $("#get-bucket-container").empty();
    $("#get-bucket-container").append(html);
}

function delOnGetHttpDone(result){
	var html = "<table><tr><th>filename</th><th>file size</th><th>last modified</th><th></th>";
    var prefix = "foo4212/";
    for(var i=0; i<result.length; i++){
    	var filename = (result[i][0]==prefix)? result[i][0].replace(prefix, "..") : result[i][0].replace(prefix, "");
    	var delete_pathname = baseFileApiUrl+"/file/"+filename;
        html+="<tr><td>";
        html+=filename;
        html+="</td><td>";
        html+=result[i][1];
        html+="</td><td>";
        html+=result[i][2];
        html+="</td><td><input type='button' value='delete' onclick='fileApiService.httpDel(\""+delete_pathname+"\", onDelDone)'/>";
        html+="</td></tr>";
    }
    html+="<table>"
    $("#del-bucket-container").empty();
    $("#del-bucket-container").append(html);
}

function onDelDone(result){
	var pathname = baseFileApiUrl+"/info/foo4212/";
	if(result) {
		alert("delete ok");
		fileApiService.getHttp(pathname, delOnGetHttpDone);
	}
	else alert("delete error");
	
}

function onGetJsonDone(result){
	var id= result.id;
	var name= result.name;
	var html = "<table><tr><td>ID</td><td>"+id+"</td></tr><tr><td>NAME</td><td>"+name+"</td></tr>";
	html+="<tr><td>WORDS</td><td><ul style='padding:0'>";
	for(var i=0; i<result.words.length; i++){
		html+="<li>"+result.words[i].hwd+"</li>";
	}
	html+="</ul></td></tr><table>";
	$("#get-json-container").empty();
	$("#get-json-container").append(html);
}

function onFileUploadDone(result){
	if(result) alert("file uploaded successfully!");
	else alert("Error in the upload");
}
/* end callback functions */

function getBucketInfo(){
    var pathname = baseFileApiUrl+"/info/foo4212/";
     fileApiService.getHttp(pathname,onGetHttpDone);
}

function fileUpload() {
    var pathname =baseFileApiUrl+"/file/";
    var file = $("#file")[0].files[0];
    pathname += file.name;
    fileApiService.fileUpload(pathname, file, onFileUploadDone);
}

function getJson(){
    var pathname = baseFileApiUrl+"/file/mywordlist_v2/thirdParty.json";
    fileApiService.getJson(pathname, onGetJsonDone, null);
}

function deleteElement(){
	var pathname = baseFileApiUrl+"/info/foo4212/";
	fileApiService.getHttp(pathname, delOnGetHttpDone)
}

function buttonStates(button, container, fct){
	if(button==null) return;
	else if(button.hasClass("active")){
        button.toggleClass("active");
        button.prop("value", "Run");
        if(container !=null) container.hide();
    }
    else{
        if(fct!=null) fct();
        button.toggleClass("active");
        button.prop("value", "Hide");
        if(container !=null) container.show();
    }
}

$(document).ready(function(){
    $("#get-image").click(function(){
    	var button = $("#get-image");
    	var container = $("#get-image-container");
    	buttonStates(button, container, getImage);
	});
    $("#get-bucket").click(function(){
        var button = $("#get-bucket");
        var container =$("#get-bucket-container");
        buttonStates(button, container, getBucketInfo);
    });
    $("#get-json").click(function(){
    	var button = $("#get-json");
        var container =$("#get-json-container");
        buttonStates(button, container, getJson);
	});
    $("#upload-file").click(function(){
    	var button = $("#upload-file");
        var container =$("#upload-form");
        buttonStates(button, container, null);
	});
    $("#buttonUpload").click(function(){fileUpload()})
    $("#delete").click(function(){
    	var button = $("#delete");
        var container =$("#del-bucket-container");
        buttonStates(button, container, deleteElement);
    });
});