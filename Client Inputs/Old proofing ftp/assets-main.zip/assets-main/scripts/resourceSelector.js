const ACTIVE = "active";
const ALL_SELECTOR = ".selector span.all";
const RESOURCE_ID = "data-resource-id";
const RESOURCES = ".resources .resource";
const SELECTORS = ".selector span:not(.all)";
const TRANSITION_SPEED = 400;

// Display / Hide a resource
$(SELECTORS).click(function(){
    $(this).toggleClass(ACTIVE);
    $("#"+ $(this).attr(RESOURCE_ID)).toggle(TRANSITION_SPEED);

    updateAllSelector();
});

//Set bool to true to display, false to hide
function updateAllSelector(){
    if ($(SELECTORS + "." + ACTIVE).length == $(SELECTORS).length)
        $(ALL_SELECTOR).addClass(ACTIVE);
    else
        $(ALL_SELECTOR).removeClass(ACTIVE);
}

//Selector "All" behavior
$(ALL_SELECTOR).click(function() {
    $(this).toggleClass(ACTIVE);
    if($(this).hasClass(ACTIVE))
      toggleAllSelectors(true);
    else
      toggleAllSelectors(false);
});

//Set show to true to display, false to hide
// toggleClass( className, addOrRemove ) doesn't work
function toggleAllSelectors(show){
    if(show) {
        $(SELECTORS).addClass(ACTIVE)
        $(RESOURCES).each(function() {
            $(this).show(TRANSITION_SPEED);
        });
    } else {
        $(SELECTORS).removeClass(ACTIVE)
        $(RESOURCES).each(function() {
            $(this).hide(TRANSITION_SPEED);
        });
    }
}


//Init all selectors label to be like the tilte of the divs they toggle
$(SELECTORS).each(function() {
    $(this).text($("#"+ $(this).attr(RESOURCE_ID) + " h1").text());
});
