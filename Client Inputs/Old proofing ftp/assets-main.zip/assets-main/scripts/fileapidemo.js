var myPath = '';
var lastDirName = [];
var toUpdateBucketExplorer = false;

var operationList = Ext.create('Ext.data.Store',{
    fields:['label', 'value'],
    data:[
        {"value": 'create_update' , "label":'Create/Update'},
        {"value": 'get' , "label":'Get'},
        {"value": 'deleteFile' , "label":'Delete'},
        {"value": 'getInf' , "label":'Get File/Folder Infos'}
    ]
});

var usefield = {
    get: new Array('filename'),
    deleteFile: new Array('filename'),
    create_update: new Array('file'),
    getInf: new Array('filename')
}

var formElements = new Array('filename', 'file');

var operationUrl = {
    create_update: '/file/',
    get: '/file/',
    deleteFile: '/file/',
    getInf: '/info/'
}

/* define our data model */
Ext.define('Operation', {
    extend: 'Ext.data.Model',
    fields: [
        'apiUrl',
        'usrDir',
        'operation',
        'path'
    ]
});

Ext.define('File', {
    extend: 'Ext.data.Model',
    fields: [
        'file_name'
    ]
});

/** DATA STORAGE DEFINITION **/
/* data store for the files */
var myData = Ext.create('Ext.data.Store', {
    model:'File'
});

var getInfoData = Ext.create('Ext.data.Store', {
    model:'File'
});

/* define the storage which is bonded to the grid 
 */ 
var myStore = Ext.create('Ext.data.Store', {
    model:'Operation'
});
/** END OF DATA STORAGE DEFINITION **/


/* to create a panel which has 2 tab 
 * first child: form
 * second child: bucket explorer (blank view for the moment)
 */
function initApiInterface() {
    if (!userId) {
        $("#apidemo-login-msg").show();
        return;
    }
    var mainView = Ext.create('Ext.tab.Panel', {
        width:400,
        height:300,
        activeTab:0,
        border:true,
        renderTo:Ext.get('api_container'),
        id:'mainView',
        items:[
            getFormPanel(),
            getBucketExpView()
        ],
        listeners:{
            tabchange:function(tabpanel, tab){
                $('#imgPreview').remove();
                
                var activeTabId = tabpanel.getActiveTab().id;
                if(activeTabId =='bucketExpView') {
                    /* hide the resultPanel if it is displayed */
                    var resultPanel = Ext.get('resultPanel');
                    var getInfoPanel = Ext.get('getInfoView');
                    if(resultPanel!=null) 
                        Ext.getCmp('resultPanel').getEl().hide();
                    if(getInfoPanel!=null) 
                        Ext.getCmp('getInfoView').getEl().hide();
                }
                else if (activeTabId=='formPanel'){
                    if(myStore.count()>0) Ext.getCmp('resultPanel').getEl().show();
                    if(getInfoData.count()>0) Ext.getCmp('getInfoView').getEl().show();
                }
            }
        }
    });
    if(mainView){
        Ext.getCmp('validateForm').disable(true);
        Ext.getCmp('resetForm').disable(true);
        Ext.getCmp('mainView').down('#formPanel').setDisabled(true);
        Ext.getCmp('mainView').down('#bucketExpView').setDisabled(true);
    }
}

function getFormPanel(){
    return new Ext.create('Ext.form.Panel',{
        fileUpload:true,
        width:300,
        height:300,
        border:false,
        id:'formPanel',
        title:'Form',
        padding:10,
        defaults:{width:350}, //to determine it dynamically if possible
        items:[
            {xtype:'textfield',
             fieldLabel:'API base URL',
             name:'apiUrl',
             value:baseFileApiUrl,
             emptyText:'Enter the API url',
             readOnly: true},
             
            {name:'usrDir',
             value:userId,
             fieldLabel:'User Directory',
             xtype:'textfield',
             emptyText:'Enter the user directory',
             readOnly:true},
             
             {fieldLabel:'Operation',
              name:'operation',
              emptyText:'Select an Operation',
              forceSelection:true,
              xtype:'combobox',
              store:operationList,
              queryMode:'local',
              displayField:'label',
              valueField:'value',
              listeners:{
                afterrender: function(){
                    var form= this.up('form').getForm();
                    for(var i=0; i< formElements.length; i++){
                        form.findField(formElements[i]).setDisabled(true);
                        form.findField(formElements[i]).hide();
                    }
                }, 
                change: function(combo, newValue, oldValue, eOpts){
                    var form= this.up('form').getForm();
                    for(var i=0; i< formElements.length; i++){
                        form.findField(formElements[i]).setDisabled(true);
                        form.findField(formElements[i]).hide();
                        
                    }
                    var dependant = usefield[newValue];
                    if(dependant==null) return;
                    for(var i=0; i<dependant.length; i++){
                        form.findField(dependant[i]).setDisabled(false);
                        form.findField(dependant[i]).show();
                        
                    }
                }
              } },
             
             {
                xtype: 'textfield',
                id: 'path',
                name: 'path',
                fieldLabel: 'Path',
                emptyText: 'Enter the path'
             },
             
             {
                xtype: 'textfield',
                id: 'filename',
                name: 'filename',
                fieldLabel: 'Filename',
                emptyText: 'Enter the filename'
             },

             {
                xtype: 'textfield',
                id: 'file',
                name: 'file',
                fieldLabel: 'File',
                inputType: 'File'
             },
             
             {xtype: 'toolbar',
              dock: 'bottom',
              ui: 'footer',
              defaults: {minWidth: 30},
              items:[
                {margin: 5,
                 formBind: true,
                 text: 'Submit',
                 id: 'validateForm',
                 handler:
                    function(){
                        var form = this.up('form').getForm();
                        apiCall(form);
                    }
                }, 
                {margin: 5,
                 formBind: true,
                 text: 'Reset',
                 id: 'resetForm',
                 handler: function() {
                     var form = this.up('form').getForm();
                     myReset(form);
                    }
                }]
             }
        ]
    });
}

function reinitPath(){
    myPath = '';
    lastDirName =[];
}

function myReset(form){
    form.findField('apiUrl').setValue(baseFileApiUrl);
    form.findField('path').setValue('');
    form.findField('filename').setValue('');
}

/* function which handles the submit 
 */
function isFormValid(form){
    var operation = form.findField('operation').getValue();
    if(operation==null)
        return false;
    return true;
}

/* get the result view after submitting the form */
function getResultView(){
    var resultPanel = Ext.create('Ext.grid.Panel', {
        renderTo: Ext.get('resultView_container'),
        title:'Operation requested',
        height: 200,
        width: 400,
        id: 'resultPanel',
        store:myStore,
        columns:[
            { header:'Api Url', dataIndex:'apiUrl'},
            { header:'User Dir.', dataIndex:'usrDir'},
            { header:'Operation', dataIndex:'operation'},
            { header:'Path', dataIndex:'path'}
        ]
    });
    return resultPanel;
}

function getInfoView(){
    var getInfoPanel = Ext.create('Ext.grid.Panel', {
        renderTo: Ext.get('getInfo_container'),
        title:'Get Info View',
        height: 200,
        width: 400,
        id: 'getInfoView',
        store:getInfoData,
        columns:[
             { header:'Name', dataIndex:'file_name', flex:1},
             { header:'Size(octets)', dataIndex:'size'},
             { header:'Date', dataIndex:'date'},
         ],
    });
    return getInfoPanel;
}

/* due to security issue, chrome, opera, IE display a "fakepath" before the name of the file */
function getFileUploadName(fullpath){
    var component = fullpath.split('\\'); 
    if(component.length==1) return component[0];
    else{
        var i=0; 
        while(component[i+1]!=null) i++; 
        return component[i];
    }
}

/** CALLBACK FUNCTIONS **/
function cbCreate(cond){
    if(cond) {
        alert("file uploaded successfully!");
        toUpdateBucketExplorer = true;
        refreshBucketExp();
    }
    else alert("upload file error!")
}

function cbDelete(cond, filename, pathname){
    if(cond) {
        if(pathname.replace(userId + "/","") == myPath){
            for(var i=0; i<myData.count(); i++){
                if(myData.getAt(i).get('file_name') == filename){
                    myData.removeAt(i);
                    Ext.getCmp("BucketContainer").getView().refresh();
                }
            }
        }
        else return;
        alert("Deletion ok");
    }
    else alert("delete file error!");
}

function cbGetInfo(data){
    listS3Bucket(data,getInfoData);
    var getInfoPanel = Ext.get('getInfoView');
    if(getInfoPanel==null) getInfoPanel = getInfoView();
}
/** END OF CALLBACK FUNCTIONS **/

function apiCall(form){
    if(isFormValid(form)){
        var destUrl = form.findField('apiUrl').getValue() ;
        var pathname = form.findField('path').getValue();
        if(pathname.substr(pathname.length-1)!="/")pathname+="/";
        var operation = form.findField('operation').getValue();
        var apiPath = operationUrl[operation];
        //reinitPath(); 
        switch (operation){
        case "get": 
            var filename = form.findField('filename').getValue(); 
            destUrl += apiPath+pathname+filename;
            window.open(destUrl, '_blank'); 
            break;
        case "create_update":
            var filename = getFileUploadName(form.findField('file').getValue());
            var file = $("#file input")[0].files[0]
            destUrl += apiPath+pathname+filename;
            fileUpload(destUrl, file, cbCreate); 
            break;
        case "deleteFile":
            var filename = form.findField('Filename').getValue();   
            destUrl += apiPath+pathname+filename;
            httpDel(destUrl, cbDelete, filename, pathname); 
            break;
        case "getInf":
            var filename = form.findField('filename').getValue();
            destUrl += apiPath+pathname+filename;
            httpGet(destUrl, cbGetInfo);
            break;
        default: 
            break;
        }
        var resultPanel = Ext.get('resultPanel');
        if(resultPanel==null) resultPanel = getResultView();
        myStore.add({
            apiUrl: form.findField('apiUrl').getValue(),
            usrDir: form.findField('usrDir').getValue(), 
            operation: operation,
            path: form.findField('path').getValue()
        });
        return;
    }
    return;
}


function getBucketExpView(){
    refreshBucketExp();
    return new Ext.create('Ext.form.Panel',{
        //width:300,
        //height:300,
        autoScroll:true,
        autoWidth:true,
        autoHeight:true,
        id:'bucketExpView',
        title:'Bucket Explorer',
        defaults:{xtype:'displayfield'},
        items:[
            {fieldLabel:'Bucket Explorer',
             name:'title'
            }, 
            getBucketContainer()
        ]
    });
}

function getBucketContainer(){
    return new Ext.create('Ext.grid.Panel', {
        width:395, 
        height:200, 
        id:'BucketContainer',
        padding:5,
        border:true,
        columns:[
            { header:'Name', dataIndex:'file_name', flex:1},
            { header:'Size(octets)', dataIndex:'size'},
            { header:'Date', dataIndex:'date'},
        ],
        hideHeaders:false,
        store:myData,
        listeners : {
            itemdblclick: function(dv, record, item, index, e){
                // double click on a directory
                if(record.get('file_name').indexOf('/')!=-1){
                    myPath+=record.get('file_name');
                    lastDirName.push(record.get('file_name'));
                    refreshBucketExp();
                }
                else if(record.get('file_name') ==".."){
                    var getLastDir = lastDirName.pop();
                    if(getLastDir != undefined || getLastDir != null) {
                        myPath = myPath.replace(getLastDir,"");
                        refreshBucketExp();
                    }
                }
                // double click on a file
                else {
                    var destUrl = baseFileApiUrl + "/file/" + myPath+ record.get('file_name');
                    httpObjDisplay(destUrl);
                }
            }
        }
    });
}

function refreshBucketExp(){
    /* get the bucket content */
    var destUrl = baseFileApiUrl + "/info/" + userId + "/"+myPath;
    httpGet(destUrl, listS3Bucket);
    if(myData.count()>0) {
        myData.removeAll();
        httpGet(destUrl, listS3Bucket);
    }
    return;
}

function listS3Bucket(data, dataStorage) {
    var storageUsed = (dataStorage==null || dataStorage==undefined)?myData:dataStorage;
    if(storageUsed.count()>0) storageUsed.removeAll();
    var subData;
//    console.log("listS3Bucket: data lenght = "+data.length);
    for ( var i = 0; i < data.length; i++) {
        subData = data[i];
//        console.log(subData[0])
        //directory
        if(subData[0]&&subData.indexOf("S3Object")==-1){
            if(subData[0][subData[0].length-1]=='/'){
                if(subData[0]==userId+'/'+myPath) storageUsed.add({ file_name:subData[0].replace(userId+'/'+myPath,'..') });
                else storageUsed.add({
                    file_name:subData[0].replace(userId+'/'+myPath,'')
                 });
            }
            else {
//                console.log(subData);
                storageUsed.add({
                    file_name:subData[0].replace(userId+'/'+myPath,''),
                    size:subData[1],
                    date:subData[2]
                });
            } 
        }
        //unique object
        else if(subData.indexOf("S3Object")>=0){
            storageUsed.add({
                file_name:data[0].split("=")[1].split(",")[0].replace(userId+'/',''),
                size:data[1],
                date:data[2]
            });
            return;
        }
    }
}


/* functions : get directory, add file, delete file, display file, etc ... */

function httpGet(url, cb){
    $.ajax({
        url : url,
        type : 'GET',
        cache : false,
        beforeSend: function(){
            $("#apidemo-processing-msg").show();
            Ext.getCmp('validateForm').disable(true);
            Ext.getCmp('resetForm').disable(true);
            if(Ext.getCmp('mainView')) {
                Ext.getCmp('mainView').down('#formPanel').setDisabled(true);
                Ext.getCmp('mainView').down('#bucketExpView').setDisabled(true);
            }
        },
        success : function(data) { 
//            console.log("Get ok");
        },
        complete : function() {
//            console.log("Get complete.");
            $("#apidemo-processing-msg").hide();
            Ext.getCmp('validateForm').enable(true);
            Ext.getCmp('resetForm').enable(true);
            if(Ext.getCmp('mainView')) {
                Ext.getCmp('mainView').down('#formPanel').setDisabled(false);
                Ext.getCmp('mainView').down('#bucketExpView').setDisabled(false);
            }
        },
        error : function(data) {
//            console.log("ERROR in get :");
            // TO DEBUG - get File (ERROR in get [object Object]/Get complete./type: file/File Data: null")
            $.each($.parseJSON(data), function(item, value) {
                $.each(value, function(i, object) {
                    $.each(object, function(subI, subObject) {
//                        console.log(subI + "=" + subObject);
                    });
                });
            });
        }
    }).done(function(data) {
        cb(data);
    });
}

function httpObjDisplay(url) {
    $('#imgPreview').remove();
//    console.log("File to display: " + url + ", extension: " + url.substring(url.length - 3, url.length));
    switch (url.substring(url.length - 3, url.length)) {
    case "jpg":
    case "bmp":
    case "png":
    case "gif":
        var img = $("<img id='imgPreview' style='width:100px;'/>").attr('src', url).load(function() {
            if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth == 0) {
                alert('broken image!');
            } else {
                $("#imgGet").append(img);
            }
        });
        break;
    case "mp3":
    case "ogg":
        break;
    }
}

function httpDel(destUrl, cb, filename, pathname) {
//    console.log("URL: " + destUrl);
    $.ajax({
        url : destUrl,
        type : 'DELETE',
        success : function() {
            cb(true, filename, pathname);
        },
        complete : function() {
//            console.log("Deletion complete.");
        },
        error : function(data) {
            console.log("ERROR in deletion " + data);
            cb(false,filename,pathname);
        }
    });
}

function fileUpload(destUrl, file, cb) {
//    console.log("* fileUpload : " + destUrl + " // " + file + " // " + cb);
    var fd = new FormData();
    fd.append("file", file);
    fd.append("redirect", true);
//    console.log("form data " + fd);

    var token = $("meta[name='_csrf']").attr("content");
    var header = $("meta[name='_csrf_header']").attr("content");

    $.ajax({
        url : destUrl,
        type : 'POST',
        method : 'PUT',
        cache : false,
        data : fd,
        // Options to tell jQuery not to process data or worry about content-type.
        cache : false,
        contentType : false,
        processData : false,
        crossDomain : true,
        beforeSend: function(xhr){
            xhr.setRequestHeader(header, token);
        },
        success : function() {
//            console.log("Upload ok");
            cb(true);
        },
        complete : function() {
//            console.log("upload complete.");
        },
        error : function(res) {
//            console.log("ERROR in upload " + res);
            cb(false);
        }
    });
}
/* end of functions : get directory, add file, delete file, etc ... */ 

/* force the hidden elements to be well indented */
$(document).ready(function(){
    $("#filename label").width(100);
    $("#file label").width(100);
});
/* end force the hidden elements to be well indented */