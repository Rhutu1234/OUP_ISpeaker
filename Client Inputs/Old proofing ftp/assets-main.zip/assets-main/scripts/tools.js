function FileApiService(){}

FileApiService.prototype.getHttp = function(pathname, cb){
    $.ajax({
         url : pathname,
         type : 'GET',
         cache:false,
         success : function() {
//             console.log("Get ok");
         },
         complete : function() {
//             console.log("Get complete.");
         },
         error : function(data) {
             console.log("ERROR in get :");
             console.log(data);
         }
    }).done(function(data) {
    	cb(data);
    });
}

FileApiService.prototype.getJson = function (pathname, cb, jsonpCb){
    jsonpCb = (jsonpCb==null)?"jsonpCallbackFunction":jsonpCb;
    $.ajax({
        type:'GET',
        url: pathname,
        dataType: 'jsonp',
        jsonp: false,
        jsonpCallback: jsonpCb,
        crossDomain:true,
        success: function(){
//            console.log("get JSON success");
        },
        error:function(data){
            console.log("ajax error !");
            console.log(data);
        }
    }).done(function(data){
    	cb(data);
    });
}

FileApiService.prototype.fileUpload = function(pathname, file, cb) {
    var fd = new FormData();
    fd.append("file", file);
    fd.append("redirect", true);

    var token = $("meta[name='_csrf']").attr("content");
    var header = $("meta[name='_csrf_header']").attr("content");


    $.ajax({
        url : pathname,
        type : 'POST',
        method : 'PUT',
        cache : false,
        data : fd,
        // Options to tell jQuery not to process data or worry about content-type.
        cache : false,
        contentType : false,
        processData : false,
        crossDomain : true,
        beforeSend: function(xhr){
            xhr.setRequestHeader(header, token);
        },
        success : function() {
//            console.log("Upload ok");
            cb(true);
        },
        complete : function() {
//            console.log("upload complete.");
        },
        error : function(res) {
            console.log("ERROR in upload " + res);
            cb(false);
        }
    });
}

FileApiService.prototype.httpDel = function(pathname, cb) {
    $.ajax({
        url : pathname,
        type : 'DELETE',
        success : function() {
//            console.log("Deletion ok");
            cb(true);
        },
        complete : function() {
//            console.log("Deletion complete.");
        },
        error : function(data) {
            console.log("ERROR in deletion " + data);
            cb(false);
        }
    });
}
