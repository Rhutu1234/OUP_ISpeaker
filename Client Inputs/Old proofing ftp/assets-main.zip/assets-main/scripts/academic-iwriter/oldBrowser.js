$(document).ready(

        $.reject(

                {

                    reject: {all: false, msie: 10, chrome: 34, firefox: 30, safari: 6},

                    display: ["chrome", "msie", "firefox", "safari"],

                    imagePath: "/external/images/iwriter/mitr/older/",

                    header: "Did you know that your internet browser is out of date?",

                    paragraph1: "To access the full range of the Oxford iWriter's features, please upgrade to a later version of one of the following Browsers.",

                    paragraph2: "Just click on the icons to go to the download page.",

                    close: true,

                    closeMessage: "By closing this window you accept that some features of this application may not work.",

                    closeLink: "Close this window",

                    closeURL: "#",

                    closeESC: true,

                    closeCookie: true,

                    cookieSettings: {path: "/", expires: 0}, }

        )
        );