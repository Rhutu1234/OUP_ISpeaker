function get_date() {
  var _date = new Date();
  if (iWriterLang == "cs") {
    var dd = _date.getDate();
    var mm = _date.getMonth() + 1; //January is 0!

    var yyyy = _date.getFullYear();
    if (dd < 10) {
      dd = '0' + dd
    }
    if (mm < 10) {
      mm = '0' + mm
    }
    var today = dd + '/' + mm + '/' + yyyy;
    _date = _date.toString();
    var _date_arr = _date.split(' ');
    today = today + ' ' + _date_arr[4];
    return today;
  } else {
    _date = _date.toString();
    var _date_arr = _date.split(' ');
    return _date_arr[0] + ' ' + _date_arr[1] + ' ' + _date_arr[2] + ' ' + _date_arr[3] + ' ' + _date_arr[4];
  }
}
function uploadTestJsonFile() {
  var destUrl = baseFileApiUrl + "/file/" + userId + "/test.json";
  //var json_str = 'jsonpCallbackFunction([{"id":"1","name":"First"},{"id":"2","name":"Pratik"}]);';
  var json_str = 'jsonpCallbackFunction([{"id":"1","name":"First"},{"id":"2","name":"Pratik"}]);';

  _FileApiService.fileUpload(destUrl, json_str, function (data) {
    if (data) {
      alert("JSON file successfully uploaded!");
      readTestJsonFile();
    }
  });
}

function readTestJsonFile() {
  var fileUrl = baseFileApiUrl + "/file/" + userId + "/controller-intermediate-iwriter-german.json";

  var readCallback = function (data) {
    if (data) {
      console.log(data);
    }
  };
  _FileApiService.getJson(fileUrl, readCallback, "jsonpCallbackFunction");
}

function upload_controller() {
  var destUrl = baseFileApiUrl + "/file/" + userId + "/controller-intermediate-iwriter-german.json";
  var json_str = 'jsonpCallbackFunction([]);';
  _FileApiService.fileUpload(destUrl, json_str, function (data) {
    if (data) {

    } else {
      upload_controller();
    }
  });
}

function delete_controller() {
  var destUrl = baseFileApiUrl + "/file/" + userId + "/controller-intermediate-iwriter-german.json";

  _FileApiService.httpDel(destUrl, function (data) {
    console.log(data);
  });
}

var _FileApiService = new FileApiService();

function onDocmentReady() {
  if (!userId) {
    return;
  }
  $('.responsive_entry_center_wrap,#main_column,.main-container').css('margin', '0');
  $('.responsive_entry_center_wrap,#main_column,.main-container').css('padding', '0');
  $('.middle_wrap').parent().css('margin', '0');
  $('.middle_wrap').parent().css('padding', '0');

  //readTestJsonFile();
  //delete_controller();
  //create controller json first time
  //var fileUrl = baseFileApiUrl + "/file/" + userId + "/controller-intermediate-iwriter-german.json";

  $('#langDropDown').change(function () {
    var destUrl = baseFileApiUrl + "/file/" + userId + "/language-intermediate-iwriter-german.json";
    var json_str = 'jsonpCallbackFunction(' + JSON.stringify({"language": $(this).val().toString()}) + ');';
    _FileApiService.fileUpload(destUrl, json_str, function (data) {
      if (data === true) {
        window.location.href = window.location.href;
      }
    });
  });

  var user_folder = baseFileApiUrl + '/info/' + userId + '/';
  _FileApiService.getHttp(user_folder, function (data) {
    if (data.length != 0) {
      var controller_status = false;
      for (var i in data) {
        var n = data[i][0].indexOf("controller-intermediate-iwriter-german.json");
        if (n != (-1)) {
          controller_status = true;
          break;
        }
      }
      if (!controller_status) {
        upload_controller();
      }
    }

  });
  //end create controller json first time

  //load saved projects
  var fileUrl = baseFileApiUrl + "/file/" + userId + "/controller-intermediate-iwriter-german.json";

  var get_saved_projects = function (cb_data) {
    console.log('controller-intermediate-iwriter-german.json object');
    console.log(cb_data);
    if (cb_data) {
      var _cb_data = new Array();
      //make in descending order
      //console.log(cb_data);
      for (var i in cb_data) {
        if (cb_data[i].language === toolLang + '_' + iWriterLang) {
          _cb_data.push(Number(cb_data[i]['timestamp']));
        }
      }
      _cb_data.sort();
      _cb_data.reverse();

      var temp_obj = new Array();
      for (var i in _cb_data) {
        for (var k in cb_data) {
          var t_str = (cb_data[k]['timestamp']).toString();
          var n = t_str.indexOf(_cb_data[i].toString());
          if (n != (-1)) {
            temp_obj[i] = new Object();
            temp_obj[i] = cb_data[k];
          }
        }
      }

      if (temp_obj.length == 0) {
        console.log('no projects saved');
        $('.save_p_btn_txt').html('<span>' + jsonData["no_projects_saved"] + '</span></span>');
      } else {
        var temp_html = '';
        for (var i in temp_obj) {

          var _name = temp_obj[i]['project_name'].replace(/\#\|\#/g, "'");
          _name = _name.replace(/\#\|\|\#/g, '"');

          temp_html += '<div class="saved_projects_list" data-key="' + temp_obj[i]['data_key'] + '" data-project="' + temp_obj[i]['project_name'] + '" data-type="save" data-file_name="' + temp_obj[i]['file_name'] + '">' + _name + '</div>';
        }
        temp_html += '<div class="saved_projects_list">&nbsp;</div>';

        $('.save_p_btn_txt').html('<span>' + jsonData["my_saved_writing"] + '</span><span class="up_home"></span>');
        $('.saved_projects').empty().html(temp_html);

        $('.saved_projects').perfectScrollbar({suppressScrollY: false});
        var _hgt = $('.saved_projects').height();
        $('.saved_projects').attr("actHgt", _hgt).css("overflow", "hidden").css("height", _hgt + "px");
        $('.saved_projects').height($('.save_p_btn').height());
        var svd_pro_hgt = $('.saved_projects').height();

        $('.save_p_btn').bind('click', function (e) {

          e.preventDefault();
          $('.saved_projects').stop();

          if (Number(svd_pro_hgt) === 39 || Number(svd_pro_hgt) === 32)
          {
            $('.saved_projects').animate({height: $('.saved_projects').attr("actHgt")}, 500);
          } else
          {
            $('.saved_projects').animate({height: svd_pro_hgt}, 500);
          }
          if ($('.saved_projects').height() > $('.save_p_btn').height()) {
            $('.saved_projects').animate({height: $('.save_p_btn').height()}, 500);
          }
        });

        $('.saved_projects_list').off('click').on('click', function () {
          if ($(this).attr('data-type') == 'create') {
            iWiter_controller.current_pro_name = '';
          } else {
            iWiter_controller.current_pro_name = $(this).attr('data-project');
          }
          iWiter_controller.file_name = $(this).attr('data-file_name');
          iWiter_controller.create_project($(this).attr('data-key'), $(this).attr('data-type'), $(this).attr('data-project'));
        });



        var p_len = ($('.saved_projects_list').length) - 1;
        $('.saved_projects_list:nth-child(' + p_len + ')').css('border-bottom', 'none');
      }
      //end make in descending order
    }
  };
  _FileApiService.getJson(fileUrl, get_saved_projects, "jsonpCallbackFunction");
  // end load saved projects

  $('.help_btn').off(event_type).on(event_type, function () {
    if (iWriterLang == "cs") {
      var OpenWindow = window.open("/external/xml/intermediate-iwriter/" + toolLang + "/cs/help.html", "Help Document", '');
    } else {
      var OpenWindow = window.open("/external/xml/intermediate-iwriter/" + toolLang + "/en/help.html", "Help Document", '');
    }
  });


  $('.export_doc').off(event_type).on(event_type, function () {
    var doc_data = new Object();
    doc_data[0] = new Object();
    doc_data[1] = new Object();
    var cnt = 0;

    $('.content_contents').each(function (e) {
      if ($(this).text().trim() != $(this).attr('data-ph')) {
        doc_data[0][cnt] = $(this).html();
        doc_data[1][cnt] = $(this).attr('data-align');
        cnt++;
      }
    });

    if (doc_data.length != 0) {

      var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
      if (is_chrome) {
        var _temp_arr = new Array();
        var _string = '';
        for (var i in doc_data[0]) {
          var _str = doc_data[0][i].replace(/\<br\>/g, "/ppp");
          _str = _str.replace(/\<div\>/g, "/ppp<div>");
          var temp_str = _str.split('/ppp<div>');
          for (var k in temp_str) {
            _temp_arr.push(temp_str[k]);
          }
        }
        for (var i in _temp_arr) {
          if (_temp_arr[i] == '/ppp</div>') {
            _temp_arr[i] = '\r\n';
          } else {
            _temp_arr[i] = _temp_arr[i].replace(/\<\/div\>/g, "");
            _temp_arr[i] += '\r\n';
          }
          _string += _temp_arr[i];
        }
        _string = _string.replace(/\/ppp/g, " ");
        _string = _string.replace(/(<([^>]+)>)/ig, "");
        _string = _string.replace(/\&nbsp\;/g, " ");
      } else {
        if (doc_data.length != 0) {
          var temp = '';
          var domString = '';
          if (doc_data[0].length != 0) {
            for (var i in doc_data[0]) {
              temp = doc_data[0][i];
              domString += "<br>" + ((temp == "<br>") ? "" : temp);
            }

          }
        }
        var _string = domString.replace(/\<br\>/g, "\r\n");
        _string = _string.replace(/\&nbsp\;/g, " ");
      }

      function saveTextAsFile()
      {
        var textToWrite = _string;//Your text input;
        var textFileAsBlob = new Blob([textToWrite], {type: 'text/plain'});
        var fileNameToSaveAs = 'my_project';//Your filename;

        var downloadLink = document.createElement("a");
        downloadLink.download = fileNameToSaveAs;
        downloadLink.innerHTML = "Download File";
        $(downloadLink).attr('target', '_blank');
        if (window.webkitURL != null)
        {
          // Chrome allows the link to be clicked
          // without actually adding it to the DOM.
          downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
        } else
        {
          // Firefox requires the link to be added to the DOM
          // before it can be clicked.
          downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
          downloadLink.onclick = destroyClickedElement;
          downloadLink.style.display = "none";
          document.body.appendChild(downloadLink);
        }
        downloadLink.click();

        function destroyClickedElement(e) {
          console.log(e);
        }
      }
      function cleanContentEditableDiv(div) {
        var htmlString = div;
        htmlString = htmlString.replace(/<\/p>/gim, "<br/>");
        htmlString = htmlString.replace(/<p>/gim, "<br/>");
        return htmlString;
      }
      function msieversion()
      {
        var ua = window.navigator.userAgent
        var msie = ua.indexOf("MSIE ")

        if (msie > 0)      // If Internet Explorer, return version number
          return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)))
        else                 // If another browser, return 0
          return 0

      }
      if (msieversion() !== 0) {
        //_string = cleanContentEditableDiv(_string);
      }
      //saveTextAsFile();
      var file_name_to_upload = "";

      if (typeof (iWiter_controller.current_pro_name) != "undefined") {
        file_name_to_upload = iWiter_controller.current_pro_name.replace(/[^a-zA-Z]/g, "");
      }

      var pathname = baseFileApiUrl + "/file/proname_" + file_name_to_upload + ".txt";

      _FileApiService.fileUpload(pathname, _string, function (status) {
        if (status) {
          var exportUrl = baseFileApiUrl + "/file/proname_" + file_name_to_upload + ".txt";
          var OpenWindow = window.open(exportUrl, "Project Document", '');
        }
      });
    }
  });


  $('.main_wrapper').parent().css('background-color', '#e0f2fd').css('padding', '0');

  $('.models_page_body_right').click(function (e) {
    var left_pos = $('.models_page_body_left').position();

    if (Number(left_pos.left) == 0) {
      if ($(window).width() <= 480) {
        $('.models_page_body_left').animate({'left': '-100%'});
        $('.left_menu').css('background-position', '0px 0px');
      } else {
        $('.models_page_body_left').animate({'left': '-100%'});
        $('.left_menu').css('background-position', '0px 0px');
      }
    }
    $('.tool_wrapper,.down_arrow_wrapper').hide();
  });

  $('.first_page .box').css('background', 'none repeat scroll 0 0 #ebba17');

  $(window).resize(function () {
    //set_max_height();
    if (Number($(window).width()) <= 768) {
      $('.second_page_top h1').text(jsonData["choose_a_model"]);

      if ($('.left_wrapper').is(':visible')) {
        $('.show_structure_panel').removeAttr('style').hide();
        $('.show_structure_panel').hide();
      } else {
        $('.show_structure_panel').show();
        $('.left_wrapper').hide();
      }
      $('.models_page_body').scrollTop(0);
    } else {
      if (iWiter_controller.current_tool == "model") {
        $('.second_page_top h1').text(jsonData["choose_a_model"]);
      } else {
        $('.second_page_top h1').text(jsonData["model_want_to_see"]);
      }
      $('.left_wrapper').removeAttr('style').show();
      $('.show_structure_panel').removeAttr('style').show();
    }
    if ($(window).width() <= 768) {
      if (iWiter_controller.project_short_name != '') {
        $('.models_page_left_panel h1').html(iWiter_controller.project_short_name);
      }
    }
  });
  $('.show_top').bind(event_type, function (e) {
    e.preventDefault();
    $('.left_wrapper').show();
    $('.show_structure_panel').removeAttr('style').hide();

    $(this).css('background-color', 'rgb(0, 18, 60)');
    $('.show_bottom').css('background-color', '#eff3fc');
  });
  $('.show_bottom').bind(event_type, function (e) {
    e.preventDefault();
    $('.show_structure_panel').show();
    $('.left_wrapper').hide();
    $(this).css('background-color', 'rgb(0, 18, 60)');
    $('.show_top').css('background-color', '#eff3fc');
  });
  /*$('.show_structure_panel').bind(event_type, function(e) {
   e.preventDefault();
   e.stopPropagation();
   alert('in');
   });*/
  $('.models_page_tools').bind(event_type, function (e) {
    e.preventDefault();
    $('.tool_wrapper').toggle();
    $('.down_arrow_wrapper,.tool_down_arrow_wrp').hide();
  });

  $('.models_page_home').bind(event_type, function (e) {
    e.preventDefault();
    //$('.common_page').hide();
    //$('.first_page,.home_help,.language_btn').show();
    //window.location.href = window.location.href;
    iWiter_controller.switchToHome();
  });

  $('.tool_down_arrow').bind(event_type, function (e) {
    e.preventDefault();
    if ($(e.target).hasClass('tool_down_arrow')) {
      //if (!$(this).find('.arrowp_wrp').is(':visible')) {
      $('.tool_down_arrow_wrp').toggle();
      //$('.arrowp_wrp').toggle();
      $('.load_pop_d,.arrowp_wrp').hide();
      //}
      $('.tool_wrapper,.down_arrow_wrapper').hide();

      $('.project_name').val('');
    }
    //alert('In');
  });
  $('.models_page_down_arrow,.down_arrow').bind(event_type, function (e) {
    e.preventDefault();
    if (!$('.arrowp_wrp').is(':visible')) {
      $('.down_arrow_wrapper').toggle();
    }
    $('.tool_down_arrow_wrp').hide();
    $('.tool_wrapper').hide();


  });

  $('.drp_home_clk').bind(event_type, function (e) {
    e.preventDefault();
    //$('.common_page').hide();
    //$('.first_page,.home_help,.language_btn').show();
    //window.location.href = window.location.href;
    //$('.tool_wrapper,.down_arrow_wrapper').hide();
    iWiter_controller.switchToHome();
  });

  $('.up_arrow').bind('click', function (e) {
    e.preventDefault();

    if (iWiter_controller.current_tool == 'writer') {

      iWiter_controller.switchFromWriter();

      //$('.fn_rigth').trigger(event_type);
    } else {
      $('.fn_left').trigger('click');
    }

  });

  $('.left_menu,.h1_click').bind(event_type, function (e) {

    if (!$('.second_page').is(':visible')) {
      e.preventDefault();
      $('.tool_wrapper,.down_arrow_wrapper').hide();
      var left_pos = $('.models_page_body_left').position();
      $('.models_page_body').scrollTop(0);
      $('.models_page_body_left').stop();
      if (Number(left_pos.left) == 0) {
        if ($(window).width() <= 480) {
          $('.models_page_body_left').animate({'left': '-100%'});
          $('.left_menu').css('background-position', '0px 0px');
        } else {
          $('.models_page_body_left').animate({'left': '-100%'});
          $('.left_menu').css('background-position', '0px 0px');
        }
        //$('.models_page_body,.second_page_body,.second_page_body_left,.models_page_body_left').css('overflow-y', 'scroll');
      } else {
        $('.models_page_body_left').animate({'left': '0'});
        //$('.models_page_body').css('overflow', 'hidden');
        $('.left_menu').css('background-position', '-5px 0px');
      }
    } else {
      e.preventDefault();
      $('.tool_wrapper,.down_arrow_wrapper').hide();
      var left_pos = $('.second_page_body_left').position();
      $('.second_page_body').scrollTop(0);
      $('.second_page_body_left').stop();
      if (Number(left_pos.left) == 0) {
        if ($(window).width() <= 480) {
          $('.second_page_body_left').animate({'left': '-100%'});
          $('.left_menu').css('background-position', '0px 0px');
        } else {
          $('.second_page_body_left').animate({'left': '-100%'});
          $('.left_menu').css('background-position', '0px 0px');
        }
        $('.models_page_body,.second_page_body,.second_page_body_left,.models_page_body_left').css('overflow-y', 'scroll');
      } else {
        $('.second_page_body_left').animate({'left': '0'});
        $('.second_page_body').css('overflow', 'hidden');
        $('.left_menu').css('background-position', '-5px 0px');
      }
    }

  });



  $('.fn_left').bind('click', function (e) {
    e.preventDefault();
    $('.common_page').hide();
    $('.second_page').show();
    $('.tool_wrapper,.down_arrow_wrapper').hide();

    iWiter_controller.leftPanelModel('li', '.second_page_body_left ul');

  });
  $('.fn_rigth').bind('click', function (e) {
    e.preventDefault();
    $('.common_page').hide();
    $('.second_page').show();
    $('.tool_wrapper,.down_arrow_wrapper').hide();
    iWiter_controller.leftPanelWriter('li', '.second_page_body_left ul');
  });
  $('.left_wrapper li,.str_common').bind(event_type, function (e) {
    if (iWiter_controller.current_tool == 'model') {
      var left_pos = $('.models_page_body_left').position();

      if (Number(left_pos.left) == 0) {
        if ($(window).width() <= 480) {
          $('.models_page_body_left').animate({'left': '-100%'});
        } else {
          $('.models_page_body_left').animate({'left': '-100%'});
        }
      }
    }

    $('.tool_wrapper,.down_arrow_wrapper').hide();
  });

  $('.models_page_body_right').bind(event_type, function (e) {
    iWiter_controller.reset_drop();
  });
  set_max_height();
  function set_max_height() {
    var window_height = Number(($(window).height() * 10) / 100);
    var _margin = $('.inner_wrapper').outerHeight(true) - $('.inner_wrapper').height();
    window_height = $(window).height() - 50 - _margin;

    $('.models_page_body,.second_page_body,.second_page_body_left,.models_page_body_right').css('min-height', window_height);
    var scroll_pos = $('.main_wrapper').position();
    $(window).scrollTop(scroll_pos.top);
    $('.models_page_body').scrollTop(0);

    $('.inner_wrapper,.main_wrapper').css('min-height', $(window).height() - _margin).css('min-height', $(window).height() - _margin);

    //$('.models_page_body,.second_page_body,.second_page_body_left,.models_page_body_left,.models_page_body_right').css('overflow-y', 'auto');

    //$('.models_page_body,.second_page_body').css('overflow-y', 'auto');
    if (Number($(window).width()) <= 480) {
      $('.second_page_top h1').text('Choose a model');
      //$('.models_page_body').css('overflow', 'hidden');
    }
  }
}
