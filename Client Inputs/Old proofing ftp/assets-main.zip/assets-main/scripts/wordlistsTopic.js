/**
 * Wordlist Header Panel
 */
// Display / Hide description
$("#toggleDescription").click(function(){
    $(".wordlistsHiddenContent").toggle(400);
    $("#toggleDescription i").toggleClass('icon-plus2 icon-minus2');
});

var typingTimer;
var doneTypingInterval = 500;
var $input = $('#wordlistsSearch');
var $cross = $('#wordlistsSearch + .cross');
var searchbtn = document.querySelector('input[type="button"]');

searchbtn.addEventListener('click', searchwordlist);

function searchwordlist(){
    clearTimeout(typingTimer);
    typingTimer = setTimeout(doScroll, doneTypingInterval);
}

$input.on('keyup', function(event) {
    clearTimeout(typingTimer);
    if(event.keyCode == 13) {
        typingTimer = setTimeout(doScroll, doneTypingInterval);
    }
});

$input.on('keydown', function() {
    clearTimeout(typingTimer);
});

$input.on('input', function(e){
    if($input.val() == "")
        $cross.css("display", "none");
    else
        $cross.css("display", "inline-block");
});

$cross.on('mousedown', function(){
    document.getElementById("wordlistsSearch").value = "";
});
$cross.on('mouseup', function(){
    $(this).css("display", "none");
});

function doScroll() {
    var searchValue = $input.val().toLowerCase();
    var $elem;
    $("#wordlistsContentPanel li:not(.hidden)").each(function() {
        var headword = $(this).attr("data-hw");
        if (headword >= searchValue) {
            $elem = $(this);
            return false;
        }
    });

    if ($elem) {
        if (isMobile) {
            $elem.get(0).scrollIntoView();
        } else {
            document.getElementById("wordlistsContentPanel").scrollTop = $elem.get(0).offsetTop
                    - document.getElementById("wordlistsContentPanel").offsetTop;
        }
    }
}

/**
 * Wordlist content panel
 */
// Display 'not in dataset' tooltip
$("data > span:first-child").click(function(e) {
    if ($("#wordlistsTooltip").is(":hidden")) {
        $("#wordlistsTooltip").css({'top':e.pageY+15,'left':e.pageX-30});
        $("#wordlistsTooltip").fadeIn(200).delay(2000).fadeOut(400);
    }
});

function applyFilters(){
    loadPanel();
    updateBreadCrumb();

    var allEntries = $("#wordlistsContentPanel li").removeClass("hidden");
    var totalEntries = allEntries.length;
    var CSSQuery = "";

    var levels = getSelectedLevel();
    var levelAvailable = getAvailableLevel();
    var list = getSelectedList();
    var listsAvailable = getAvailableList();

    var needFilteringByLevel = (typeof levels != 'undefined' && levels.length != levelAvailable.length);
    var needFilteringByList = (typeof list != 'undefined');

    if(needFilteringByList && !needFilteringByLevel){
        CSSQuery = ("[data-"+list+"]");
        allEntries = allEntries.not(CSSQuery);
    } 
    if(!needFilteringByList && needFilteringByLevel){
        for (var i = 0; i < listsAvailable.length; i++) {
            for (var j = 0; j < levels.length; j++) {
                CSSQuery = ("[data-"+listsAvailable[i]+"="+levels[j]+"]");
                allEntries = allEntries.not(CSSQuery);
            }
        }
    }
    if(needFilteringByLevel && needFilteringByList){
        for (var i = 0; i < levels.length; i++) {
            CSSQuery = ("[data-"+list+"="+levels[i]+"]");
            allEntries = allEntries.not(CSSQuery);
        }
    }

    if(needFilteringByLevel || needFilteringByList){
        allEntries.addClass("hidden");
        if(totalEntries === allEntries.length)
            $("#empty").removeClass("hidden");
        else
            $("#empty").addClass("hidden");
    }
    showPanel();
}

function loadPanel(){
    $("#wordlistsContentPanel").removeClass("loaded");
}
function showPanel(){
    $("#wordlistsContentPanel").addClass("loaded");
}

function updateBreadCrumb(){
    var selectedList = $("#filterList option:selected");
    $("#wordlistsBreadcrumb span:nth-child(2)").text(selectedList.text());

    var levels = $('.level-select input:checked');
    var levelAvailable = getAvailableLevel();
    var display = "";

    if(typeof levels == 'undefined' || levels.length == levelAvailable.length)
        display = "All";
    else{
        for (var i = 0; i < levels.length; i++) {
            display += "<i>" + levels.get(i).value + "</i>";
        }
    }   
    $("#wordlistsBreadcrumb span:nth-child(3)").html(display);
}

applyFilters();

/**
 * Wordlist Filter Panel
 */
function closeFilterMenu(){
    $("#wordlistsFilterMenu").removeClass("open");
    //reenable scroll
    $("html").removeClass("disable-scroll");
    $("#wordlistsOverlay").hide();
    $("div[id$=_feedback_minimized]").show();
}

function getSelectedList() {
    var list = getValues($('#filterList option:selected'));
    if(list.length)
        return list;
}
function getAvailableList() {
    var list = getValues($('#filterList option'));
    if(list.length)
        return list;
}
function getSelectedLevel() {
    var levels = getValues($('.level-select input:checked'));
    if(levels.length)
        return levels;
}
function getAvailableLevel() {
    var levels = getValues($('.level-select input'));
    if(levels.length)
        return levels;
}

function getValues(list){
    return list.map(function(){
        if(this.value != "ALL" && this.value != "On")
        return this.value;
    }).get();;
}

$("#wordlistsFilters, #wordlistsBreadcrumb").click(function(){
    $("#wordlistsFilterMenu").addClass("open");
    //disable scroll
    $("html").addClass("disable-scroll");
    $("#wordlistsOverlay").show(); 
    $("div[id$=_feedback_minimized]").hide();
});

$("#closemenu").click(closeFilterMenu);
$("#wordlistsOverlay").click(closeFilterMenu);

$("#saveFilters").click(function(){
    // Close the menu
    closeFilterMenu(); 

    // Refresh the content
    applyFilters();
});

/**
 * Wordlist Download Panel
 */
function closeDownloadMenu(){
    $("#wordlistsDownloadMenu").removeClass("open");
    //re-enable scroll
    $("html").removeClass("disable-scroll");
    $("#wordlistsOverlay").hide();
    $("div[id$=_feedback_minimized]").show();
}

$("#wordlistsDownload").click(function(){
    $("#wordlistsDownloadMenu").addClass("open");
    //disable scroll
    $("html").addClass("disable-scroll");
    $("#wordlistsOverlay").show();
    $("div[id$=_feedback_minimized]").hide();
});

$("#closeDownloadMenu").click(closeDownloadMenu);
$("#wordlistsOverlay").click(closeDownloadMenu);

$(".ms-parent:visible .not-all input").on("change", function(){
    $(".ms-select-all:visible input").prop('checked', isToggleAll());
})

$(".ms-select-all input").on("change", function(){
    var isChecked = $(this).prop("checked");
    $.each($(".ms-parent:visible .not-all input"), function(){
        $(this).prop("checked", isChecked);
    })
});

function isToggleAll(){
    if($(".ms-parent:visible").find('.not-all input:not(:checked)').length)
        return false;
    return true;
}