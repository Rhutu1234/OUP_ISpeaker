/* global variables */
var myModule = new MyWordlistModule();
var myScoreBoard = new ScoreBoard([]);
var myWordlist = new Wordlist('', '', []);
var mywordlist_path = baseFileApiUrl + '/file/';
var mywordlist_app_path = baseWebsiteUrl + '/external/scripts/mywordlist/';
var jsonpCall = "jsonpCallbackFunction";
/* end of global variables */

/* MyWordlistModule */
function MyWordlistModule() {

    this.loadScoreBoard = function(code, isLoggedIn) {
        // retrieve JSON files containing system wordlist directly from the application
        var jsonFilePath = (isLoggedIn ? mywordlist_path : mywordlist_app_path);
        var jsonFile = jsonFilePath + "myscoreboard.json";
        $.ajax({
            type : 'GET',
            url : jsonFile,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(data_received) {
                $("#wait").hide();
                // call the controller
                var data = data_received;

                // init arrays
                myScoreBoard.systWordlists.length = 0;
                myScoreBoard.userWordlists.length = 0;
                for ( var i = 0; i < data.length; i++) {
                    var myWordlistDesc = new WordlistDescription(data[i].id, data[i].name, data[i].type,
                            data[i].wordnb, data[i].score, (data[i].disabled == undefined) ? "false"
                                    : data[i].disabled);
                    (myWordlistDesc.type == "system") ? myScoreBoard.systWordlists.push(myWordlistDesc)
                            : myScoreBoard.userWordlists.push(myWordlistDesc);
                }
                // sort the userWordlists & the systemWordlists before fusioning them
                myScoreBoard.systWordlists.sort(function(a, b) {
                    return a.name.localeCompare(b.name);
                });
                myScoreBoard.userWordlists.sort(function(a, b) {
                    return a.name.localeCompare(b.name);
                });

                myScoreBoard.wordlists = myScoreBoard.userWordlists.concat(myScoreBoard.systWordlists);
                if (code == "home") {
                    wordlistUtils.displayScoreBoard(myScoreBoard);
                    wordlistUtils.displayCreateWordlistForm();
                }
                else if (code == "add")
                    wordlistUtils.displayScoreBoardInSelectTag(myScoreBoard, $("#wordlist-select"));
                else
                    return;
            },
            error : function() {
                //console.log("MyWordlistModule.loadScoreBoard() : ajax error");
            }
        });
    };

    this.loadWordlistEditPage = function(id, type, isLoggedIn) {
        var filename = (type == 'user') ? "mywordlist_" + id + ".json" : "systwordlist_" + id + ".json";
        var jsonFilePath = (isLoggedIn ? mywordlist_path : mywordlist_app_path);
        var jsonFile = jsonFilePath + filename;
        $.ajax({
            type : 'GET',
            url : jsonFile,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(data) {
                var jsonWordlist = data;
                myWordlist.id = jsonWordlist.id;
                myWordlist.name = jsonWordlist.name;
                for ( var i = 0; i < jsonWordlist.words.length; i++) {
                    myWordlist.addWord(jsonWordlist.words[i].dictCode, jsonWordlist.words[i].id,
                            jsonWordlist.words[i].hwd, jsonWordlist.words[i].pos, jsonWordlist.words[i].definition,
                            jsonWordlist.words[i].disabled);
                }
                myWordlist.words.sort(function(a, b) {
                    return a.hwd.localeCompare(b.hwd);
                });
                wordlistUtils.displayWordlist(myWordlist, isLoggedIn);
            },
            error : function() {
                //console.log("MyWordlistModule.loadWordlistEditPage() : " + filename + " not found!");
            }
        });
    };

    this.loadWordlistTestPage = function(id, type, isLoggedIn) {
        var filename = (type == 'user') ? "mywordlist_" + id + ".json" : "systwordlist_" + id + ".json";
        var jsonFilePath = (isLoggedIn ? mywordlist_path : mywordlist_app_path);
        var jsonFile = jsonFilePath + filename;
        $("#test-loading").show();
        $.ajax({
            type : 'GET',
            url : jsonFile,
            cache : false,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(jsonWordlist) {
                $("#test-loading").hide();
                for ( var i = 0; i < jsonWordlist.words.length; i++) {
                    var num = i;
                    if (jsonWordlist.words[i].disabled == "false")
                        myTestArray.push({
                            "num" : num + 1,
                            "hwd" : jsonWordlist.words[i].hwd,
                            "pos" : jsonWordlist.words[i].pos,
                            "definition" : jsonWordlist.words[i].definition
                        });
                }
                renderTest(jsonWordlist.name);
            },
            error : function() {
                $("#test-loading").hide();
                $("#test-fail").show();
                //console.log("MyWordlistModule.loadWordlistTestPage() : " + filename + " not found!");
            }
        });
    };

    this.updateScoreBoard = function(id, type, maxNbWords, score, code) {
        var jsonFile = mywordlist_path + "myscoreboard.json";
        $.ajax({
            type : 'GET',
            url : jsonFile,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(wordlists) {
                var destUrl = baseFileApiUrl + '/file/' + 'myscoreboard.json';
                var json_str = "[";
                for ( var i = 0; i < wordlists.length; i++) {
                    json_str += '{"id":"' + wordlists[i].id + '",';
                    json_str += '"name":"' + wordlists[i].name + '",';
                    json_str += '"type":"' + wordlists[i].type + '",';
                    json_str += '"wordnb":"';
                    json_str += (wordlists[i].id == id && wordlists[i].type == type) ? maxNbWords
                            : wordlists[i].wordnb;
                    json_str += '",';
                    json_str += '"score":"';
                    json_str += (wordlists[i].id == id && wordlists[i].type == type) ? score
                            : wordlists[i].score;
                    json_str += '"';
                    if (wordlists[i].disabled != undefined)
                        json_str += ',"disabled":"' + wordlists[i].disabled + '"';
                    json_str += (i == wordlists.length - 1) ? '}' : '},';
                }
                json_str += "]";
                var jsonp_str = jsonpCall + '(' + json_str + ');';
                wordlistUtils.saveJsonFile(jsonp_str, destUrl);

                if (code == "add")
                    window.location.href = viewpageUrl;
                else if (code == "view")
                    $("#supp").hide();
                else if (code == "testme")
                    $("#test-saving-score").hide();
            },
            error : function() {
                //console.log("MyWordlistModule.updateScoreBoard() : ajax error");
            }
        });
    };
}
/* end MyWordlistModule */

/* ScoreBoard */
function ScoreBoard(wordlists) {
    this.wordlists = wordlists;
    this.systWordlists = [];
    this.userWordlists = [];
}

ScoreBoard.prototype.wordlists = [];

ScoreBoard.prototype.getWordlistsCount = function() {
    var counter = 0;
    for ( var i = 0; i < this.wordlists.length; i++)
        if (this.wordlists[i].disabled != "true")
            counter++;
    return counter;
};

ScoreBoard.prototype.getNextUserId = function() {
    var counter = 0;
    for ( var i = 0; i < this.wordlists.length; i++) {
        if (this.wordlists[i].type == 'user')
            counter++;
    }
    return ++counter;
};

ScoreBoard.prototype.checkExistingName = function(name) {
    for ( var i = 0; i < this.wordlists.length; i++)
        if (this.wordlists[i].name == name && this.wordlists[i].disabled == "false")
            return true;
    return false;
};

ScoreBoard.prototype.createUserWordlist = function(name, code, callBack) {
    $(".wordlist-exist").hide();
    $(".wordlist-invalid").hide();
    if(name && name.length > 0 && (name.indexOf('\"')>=0 || name.indexOf('\\')>=0)) {
        $(".wordlist-invalid").css("display", "flex");
        return false;
    } else if (name && name.length > 0 && name != newWordlistDefaultText && !this.checkExistingName(name)) {
        var jsonFile = mywordlist_path + "myscoreboard.json";
        $.ajax({
            type : 'GET',
            url : jsonFile,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(data) {
                myScoreBoard.systWordlists.length = 0;
                myScoreBoard.userWordlists.length = 0;
                for ( var i = 0; i < data.length; i++) {
                    var myWordlistDesc = new WordlistDescription(data[i].id, data[i].name, data[i].type,
                            data[i].wordnb, data[i].score, (data[i].disabled == undefined) ? "false"
                                    : data[i].disabled);
                    (myWordlistDesc.type == "system") ? myScoreBoard.systWordlists.push(myWordlistDesc)
                            : myScoreBoard.userWordlists.push(myWordlistDesc);
                }
                // sort the userWordlists & the systemWordlists before fusioning them
                myScoreBoard.systWordlists.sort(function(a, b) {
                    return a.name.localeCompare(b.name);
                });
                myScoreBoard.userWordlists.sort(function(a, b) {
                    return a.name.localeCompare(b.name);
                });
                myScoreBoard.wordlists = myScoreBoard.userWordlists.concat(myScoreBoard.systWordlists);

                if (!myScoreBoard.checkExistingName(name)) {
                    var userId = myScoreBoard.getNextUserId();
                    var newWordlistDesc = new WordlistDescription(userId, name, 'user', 0, 0, "false");
                    myScoreBoard.userWordlists.push(newWordlistDesc);
                    myScoreBoard.userWordlists.sort(function(a, b) {
                        return a.name.localeCompare(b.name);
                    });
                    myScoreBoard.wordlists = myScoreBoard.userWordlists.concat(myScoreBoard.systWordlists);
                } else {
                    $(".wordlist-exist").show();
                }

                myScoreBoard.save();
                myWordlist.createWordlist(userId, name);
                if (code == "home")
                    wordlistUtils.displayScoreBoard(myScoreBoard);
                else if (code == "add") {
                    wordlistUtils.displayScoreBoardInSelectTag(myScoreBoard, $("#wordlist-select"));
                    if (callBack)
                        callBack();
                } else
                    return;
            },
            error : function() {
                //console.log("ScoreBoard.createUserWordlist() : ajax error");
            }
        });
    } else {
        $(".wordlist-exist").show();
        return false;
    }
    return true;
};

ScoreBoard.prototype.disableWordlist = function(id, type) {
    var jsonFile = mywordlist_path + "myscoreboard.json";
    $.ajax({
        type : 'GET',
        url : jsonFile,
        dataType : 'jsonp',
        jsonp : false,
        jsonpCallback : jsonpCall,
        crossDomain : true,
        success : function(data) {
            myScoreBoard.systWordlists.length = 0;
            myScoreBoard.userWordlists.length = 0;
            for ( var i = 0; i < data.length; i++) {
                var myWordlistDesc = new WordlistDescription(data[i].id, data[i].name, data[i].type,
                        data[i].wordnb, data[i].score, (data[i].disabled == undefined) ? "false"
                                : data[i].disabled);
                (myWordlistDesc.type == "system") ? myScoreBoard.systWordlists.push(myWordlistDesc)
                        : myScoreBoard.userWordlists.push(myWordlistDesc);
            }
            // sort the userWordlists & the systemWordlists before fusioning them
            myScoreBoard.systWordlists.sort(function(a, b) {
                return a.name.localeCompare(b.name);
            });
            myScoreBoard.userWordlists.sort(function(a, b) {
                return a.name.localeCompare(b.name);
            });
            myScoreBoard.wordlists = myScoreBoard.userWordlists.concat(myScoreBoard.systWordlists);

            for ( var i = 0; i < myScoreBoard.wordlists.length; i++)
                if (id == myScoreBoard.wordlists[i].id && type == myScoreBoard.wordlists[i].type)
                    myScoreBoard.wordlists[i].disabled = "true";

            myScoreBoard.save();
            wordlistUtils.displayScoreBoard(myScoreBoard);
            return;
        },
        error : function() {
            //console.log("ScoreBoard.disableWordlist() : ajax error");
        }
    });
};

ScoreBoard.prototype.save = function() {
    /* request to the api to save the scoreboard */
    var destUrl = baseFileApiUrl + '/file/' + 'myscoreboard.json';
    var json_str = '[';
    var myscoreboard = this.wordlists;
    for ( var i = 0; i < myscoreboard.length; i++) {
        json_str += '{"id":"' + myscoreboard[i].id + '",';
        json_str += '"name":"' + myscoreboard[i].name + '",';
        json_str += '"type":"' + myscoreboard[i].type + '",';
        json_str += '"wordnb":"' + myscoreboard[i].wordnb + '",';
        json_str += '"score":"' + myscoreboard[i].score + '"';
        if (myscoreboard[i].disabled != undefined)
            json_str += ',"disabled":"' + myscoreboard[i].disabled + '"';
        json_str += (i == myscoreboard.length - 1) ? '}' : '},';
    }
    json_str += ']';
    var jsonp_str = jsonpCall + '(' + json_str + ');';
    wordlistUtils.saveJsonFile(jsonp_str, destUrl);
};

ScoreBoard.prototype.getWordlistById = function(id) {
    for ( var i = 0; i < this.wordlists.length; i++) {
        if (this.wordlists[i].id == id)
            return this.wordlists[i];
    }
};
/* end ScoreBoard */

/* WordlistDescription */
function WordlistDescription(id, name, type, wordnb, score, disabled) {
    this.id = (id == null || id == undefined) ? "" : id;
    this.name = (name == null || name == undefined) ? "" : name;
    this.type = (type == null || type == undefined) ? "" : type;
    this.wordnb = (wordnb == null || wordnb == undefined) ? 0 : wordnb;
    this.score = (score == null || score == undefined) ? 0 : score;
    this.disabled = (disabled == null || disabled == undefined) ? "false" : disabled;
}

/* end WordlistDescription */

/* Wordlist */
function Wordlist(id, name, words) {
    this.id = id;
    this.name = name;
    this.words = words;
}

Wordlist.prototype.id = "";
Wordlist.prototype.name = "";
Wordlist.prototype.words = [];

Wordlist.prototype.existingWord = function(word_id) {
    for ( var i = 0; i < this.words.length; i++) {
        if (word_id != null && word_id != undefined && word_id == this.words[i].id && this.words[i].disabled == "false")
            return true;
    }
    return false;
};

Wordlist.prototype.addWord = function(dictCode, id, hwd, pos, definition, disabled) {
    var myWord = new Word(dictCode, id, hwd, pos, definition, (disabled == undefined) ? "false" : disabled);
    this.words.push(myWord);
    return;
};

Wordlist.prototype.deleteWord = function(dictCode, id, isLoggedIn) {
    for ( var i = 0; i < this.words.length; i++)
        if (dictCode == this.words[i].dictCode && id == this.words[i].id)
            this.words[i].disabled = "true";
    wordlistUtils.displayWordlist(myWordlist, isLoggedIn);
    return;
};

Wordlist.prototype.getWordsCount = function() {
    var counter = 0;
    for ( var i = 0; i < this.words.length; i++)
        if (this.words[i].disabled == "false")
            counter++;
    return counter;
};

Wordlist.prototype.createWordlist = function(id, name) {
    var destUrl = mywordlist_path + 'mywordlist_' + id + '.json';
    var json_str = '{"id":"' + id + '","name":"' + name + '", "words":[';
    for ( var i = 0; i < this.words.length; i++) {
        json_str += '{"dictCode":"' + this.words[i].dictCode + '",';
        json_str += '"id":"' + this.words[i].id + '",';
        json_str += '"hwd":"' + this.words[i].hwd + '",';
        json_str += '"pos":"' + this.words[i].pos + '",';
        json_str += '"definition":"' + this.words[i].definition + '"';
        if (this.words[i].disabled != undefined)
            json_str += ',"disabled":"' + this.words[i].disabled + '"';
        json_str += (i != this.words.length - 1) ? '},' : '}';
    }
    json_str += ']}';
    var jsonp_str = jsonpCall + '(' + json_str + ');';
    wordlistUtils.saveJsonFile(jsonp_str, destUrl);
};

Wordlist.prototype.save = function(wordlist, code) {
    this.createWordlist(this.id, this.name);
    myModule.updateScoreBoard(wordlist.id, wordlist.type, this.getWordsCount(), wordlist.score, code);
};
/* end of Wordlist */

/* Word */
function Word(dictCode, id, hwd, pos, definition, disabled) {
    this.dictCode = (dictCode == null || dictCode == undefined) ? "" : dictCode;
    this.id = (id == null || id == undefined) ? "" : id;
    this.hwd = (hwd == null || hwd == undefined) ? "" : hwd;
    this.pos = (pos == null || pos == undefined) ? "" : pos;
    this.definition = (definition == null || definition == undefined) ? "" : definition;
    this.disabled = (disabled == null || disabled == undefined) ? "false" : disabled;
}
/* end of Word */

/* Functions used in "Add to My Wordlists" */

function initAddToMyWordlistPage() {
    myModule.loadScoreBoard("add", true);
    
    $("#wordlist-select").change(function(){
        if($(this).find('option:selected').attr('value')=="create_wordlist")
            $("#create_wordlist").show();
        else
            $("#create_wordlist").hide();
    });
}

function hideWarningPanel(){
    $("#wait").hide();
    $("#wordlist-missing").hide();
    $("#def-missing").hide();
    $("#def-exist").hide();
    $("#wordlist-exist").hide();
    $("#worlist-definename").hide();
    $("#worlist-creation-failed").hide();    
}

function addToWordlist(){
    hideWarningPanel();

    // get user choices
    var def_selected = [];
    var i = 0;
    $(".sense_check_box:checked").each(function() {
        def_selected[i++] = $(this).val();
    });
    if (!def_selected.length) {
        $("#def-missing").show();
        return;
    }
    var createWordlistFinish = true;
    
    // get the selected wordlist
    var wordlist_selected = $("#wordlist-select").val();
    if (!wordlist_selected) {
        $("#wordlist-missing").show();
        return;
    }else if (wordlist_selected == "create_wordlist") {
        createWordlistFinish = false;
        var newWordlistName = $('.wl-name').val();
        if (newWordlistName == newWordlistDefaultText) {
            $("#worlist-definename").show();
            return;
        }
        if (myScoreBoard.checkExistingName(newWordlistName)) {
            $("#wordlist-exist").show();
            return;
        }
        var wl_created = myScoreBoard.createUserWordlist(newWordlistName, 'add', function callBack(){
            createWordlistFinish = true;
            // ugly method to retrieve the id of the user wordlist created just before
            wordlist_selected = myScoreBoard.getNextUserId() - 1;
        });
        if (!wl_created) {
            $("#worlist-creation-failed").show();
            return;
        }
    }

    $("#wait").show();
    (function waitToFinish() {
        if(!createWordlistFinish) {
            setTimeout(waitToFinish, 500);
        } else {
            var destUrl = mywordlist_path+'mywordlist_' + wordlist_selected + '.json';
            return $.ajax({
                type:'GET',
                url: destUrl,
                dataType: 'jsonp',
                jsonp: false,
                jsonpCallback: jsonpCall,
                crossDomain:true,
                success:function(jsonWordlist){
                    //build the myWordlist
                    myWordlist.id = jsonWordlist.id;
                    myWordlist.name = jsonWordlist.name;
                    myWordlist.words.length = 0;
                    for ( var i = 0; i < jsonWordlist.words.length; i++) {
                        myWordlist.addWord(jsonWordlist.words[i].dictCode, jsonWordlist.words[i].id,
                                jsonWordlist.words[i].hwd, jsonWordlist.words[i].pos, jsonWordlist.words[i].definition,
                                jsonWordlist.words[i].disabled);
                    }
                    //get senses infos
                    var json_str = getSenseInfos(def_selected);
                    var json_obj = $.parseJSON(json_str);

                    var save= true;
                    var def_count=0;
                    for(var i=0; i<json_obj.length; i++){
                        var pos;
                        if(json_obj[i].pos=="n")
                            pos = "noun";
                        else if(json_obj[i].pos=="v")
                            pos = "verb";
                        else
                            pos = json_obj[i].pos
                        if(!myWordlist.existingWord(json_obj[i].id)) {
                            myWordlist.addWord(json_obj[i].dictCode, json_obj[i].id, json_obj[i].form, pos,
                                    json_obj[i].def, "false");
                        }
                        else def_count++;
                    }
                    if(def_count==def_selected.length){
                        save = false;
                        hideWarningPanel();
                        $("#def-exist").show();
                        return;
                    }
                    //save the updated wordlist
                    if(save) myWordlist.save(myScoreBoard.getWordlistById(wordlist_selected), "add");
                    //set the session variable for the edit page
                    sessionStorage.setItem("id", wordlist_selected);
                    sessionStorage.setItem("type", "user");
                },
                error:function(){
                    //console.log('addToWordlist(): ajax error');
                }
            });
        }
    })();
}

function getSenseInfos(def_selected) {
    var json_str;
    var destUrl = getSenseInfosUrl;
    $.ajax({
        type : 'GET',
        url : destUrl,
        async : false,
        data : {
            ids : JSON.stringify(def_selected)
        },
        success : function() {
            //console.log("getSenseInfos(): ajax call success");
        },
        error : function() {
            //console.log("getSenseInfos(): ajax call error");
        }
    }).done(function(data) {
        json_str = data;
    });
    return json_str;
}