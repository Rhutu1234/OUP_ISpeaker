var myModule = new MyWordlistModule();

/* MyWordlistModule */
function MyWordlistModule() {
    this.getMyWordlists = function() {
        window.oldoApi.getWordlists(loadScoreBoard);
    }
    this.getMyWordlist = function() {
        window.oldoApi.getWordlist(wordlistId, getWordlistCb, getWordlistFailureCb);
    }
    this.loadWordlistTestPage = function(wordlistId) {
        $("#test-loading").show();
        window.oldoApi.getWordlist(wordlistId, loadWordlistTestPageCb, errorCb);
    };
}

/* WordlistDescription */
function WordlistDescription(id, name, type, wordnb, score) {
    this.id = (id == null || id == undefined) ? "" : id;
    this.name = (name == null || name == undefined) ? "" : name;
    this.type = (type == null || type == undefined) ? "" : type;
    this.wordnb = (wordnb == null || wordnb == undefined) ? 0 : wordnb;
    this.score = (score == null || score == undefined) ? 0 : score;
}

var loadScoreBoard = function(jsonObject) {
    var data = jsonObject;
    var myScoreBoard = {systWordlists: [],userWordlists: []};
    for ( var i = 0; i < data.systemLists.length; i++) {
        var score = data.systemLists[i].userMetadatas.score ? data.systemLists[i].userMetadatas.score : "0";
        var myWordlistDesc = new WordlistDescription(data.systemLists[i].id, data.systemLists[i].name, "system",
                data.systemLists[i].count, score);
        myScoreBoard.systWordlists.push(myWordlistDesc)
    }
    for ( var i = 0; i < data.userLists.length; i++) {
        var score = data.userLists[i].userMetadatas.score ? data.userLists[i].userMetadatas.score : "0";
        var myWordlistDesc = new WordlistDescription(data.userLists[i].id, data.userLists[i].name, "user",
                data.userLists[i].count, score);
        myScoreBoard.userWordlists.push(myWordlistDesc);
    }
    // sort the userWordlists & the systemWordlists before fusioning them
    myScoreBoard.systWordlists.sort(function(a, b) {
        return a.name.localeCompare(b.name);
    });
    myScoreBoard.userWordlists.sort(function(a, b) {
        return a.name.localeCompare(b.name);
    });

    myScoreBoard.wordlists = myScoreBoard.userWordlists.concat(myScoreBoard.systWordlists);
    displayMyWordLists(myScoreBoard);
    displayCreateWordlist();
    var creationInput = $('#create_wordlist');
    creationInput.on('keyup', function(event) {
        if(event.keyCode == 13 && creationInput.val() != "") {
            createUserWordList(creationInput.val());
        }
    });
};

var displayMyWordLists = function(myScoreBoard) {
    $(".scoreboard-container").empty();
    var wordlists = myScoreBoard.wordlists;
    var system_row = false;

    html = "<table id='myScoreboard' class='wl-table wl-home'>";
    html += "<tr>";
    html += "<th class='wl-col1'>" + TRANSLATIONS["mywordlist.home.th.title"] + "</th>";
    html += "<th class='wl-col2'>" + TRANSLATIONS["mywordlist.home.th.word"] + "</th>";
    html += "<th class='wl-col3 show_premium'>" + TRANSLATIONS["mywordlist.home.th.score"] + "</th>";
    html += "<th class='wl-col4'>" + TRANSLATIONS["mywordlist.home.th.test"] + "</th>";
    html += "<th class='wl-col5 show_premium'>" + TRANSLATIONS["mywordlist.home.th.tool"] + "</th></tr>";
    for ( var i = 0; i < wordlists.length; i++) {
        if (wordlists[i].type == "system" && !system_row) {
            html += "<tr><td colspan='5' class='wl-sub-head'>" + TRANSLATIONS["mywordlist.home.systwl_label"] + "</td></tr>";
            system_row = true;
        }
        html += "<tr>";
        html += "<td class='wl-col1' name='title'>";
        html += "<a tabindex=\"-1\" id=\"wln-" + wordlists[i].id + "\" href='" + wordlists[i].id + "'>" + wordlists[i].name + "</a>";
        html += "</td>";
        html += "<td class='wl-col2' name='wordnb'>" + wordlists[i].wordnb + "</td>";
        html += "<td class='wl-col3 show_premium' name='score'>" + wordlists[i].score + " %</td>";
        html += "<td class='wl-col4' name='test'>";
        html += "<div class='btn icon-left test-btn'>";
        html += "<a title='" + TRANSLATIONS["mywordlist.home.test"] + "' alt='" + TRANSLATIONS["mywordlist.home.test"]
                + "' href='" + wordlists[i].id + "/testme'>Take the test</a></div></td>";
        html += (wordlists[i].type != "system") ? "<td class='wl-col5 show_premium_mywordlist tool-column' name='tool'>"
                + "<div class='tool-btn' id='ToolMenu" 
                + wordlists[i].id + "' onclick='displayToolMenu(this, " + wordlists[i].id + ")'>"
                + "<a class='tool-icon' id='tool-btn-" + wordlists[i].id + "' href='#'></a>"
                + "</div>"
                + "<div class='subMenu' id='subToolMenu" + wordlists[i].id + "' name='subToolMenu'>"
                + "<div class='subToolIcon'><a></a></div>"
                + "<div class='subToolMenu renameWordlist'>"
                + "<a title = '" + TRANSLATIONS["mywordlist.home.rename"] + "' alt = '" + TRANSLATIONS["mywordlist.home.rename"]
                + "' onclick='focusName(\"" + wordlists[i].id + "\", \"" + wordlists[i].name + "\")'>Rename</a>"
                + "</div>"
                + "<div class='subToolMenu deleteWordlist'>"
                + "<a title = '" + TRANSLATIONS["mywordlist.home.delete"] + "' alt = '" + TRANSLATIONS["mywordlist.home.delete"] 
                + "' onclick='deleteWordlist(\"" + wordlists[i].id + "\")'>Delete</a>"
                + "</div></div>"
                + "</td>"
                : "<td class='hide-delete-icon'></td>";
        html += "</tr>";
    }
    html += '</table>';
    $(html).appendTo('.scoreboard-container');

    // loop on the table to disable the take a test button for wordlists which have 0 words in it
    $("#myScoreboard > tbody > tr").each(function() {
        var currentTd = $(this).find('td[name=wordnb]');
        var nbWords = currentTd.html();
        if (nbWords == 0) {
            $(this).find("div.test-btn > a").bind("click", function() {
                alert("You cannot take a test with an empty wordlist!");
                return false;
            });
        }
    });
    
    $(document).click(function(e){
        var allToolBtn = document.getElementsByClassName("tool-icon");
        for (var i=0; i < allToolBtn.length; i++){
            if (e.originalEvent.path) {
                if(e.originalEvent.path.indexOf(allToolBtn[i])>=0)
                    return false;
            } else if(e.originalEvent.target) {
                if(allToolBtn[i] == e.originalEvent.target)
                    return false;
            }
        }
        $(".subMenu").hide();
        resetToolIcon();
    });

    return;
};

var getWordlistCb = function(jsonData) {
    // Sort alphabetically by headword
    jsonData.wordlistEntries.sort(function(a, b) {
        return a.headword.localeCompare(b.headword);
    });
    displayWordlist(jsonData);
};

var getWordlistFailureCb = function() {
    window.location.href = window.oldoApi._baseUrl + "mywordlist/";
}

var loadWordlistTestPageCb = function(jsonWordlist){
    $("#test-loading").hide();
    var words = jsonWordlist.wordlistEntries;
    for( var i = 0; i < words.length; i++) {
        myTestArray.push({
            "num" : i + 1,
            "headword" : words[i].headword,
            "pos" : words[i].pos,
            "definition" : words[i].definition
        });
    }

    renderTest(jsonWordlist.name);
};

var errorCb = function(){
    $("#test-loading").hide();
    $("#test-fail").show();
};

/*
 * Consider systemlist as userlist when system user is logged
 */
var isUserWordlist = function(wordlistUserId) {
    return currentUserId == wordlistUserId || (systemUserId == currentUserId);
};

var displayWordlist = function(jsonWordlist){
    var words = jsonWordlist.wordlistEntries;
    var count = words.length;
    var wordlistUserId = jsonWordlist.userId;

    $("#wordlist-name").empty();
    $(".nbWords").empty();
    $('.wordlist-container').empty();

    $("#wordlist-name").append(jsonWordlist.name);
    $(".nbWords").append(count);
    $("#supp").hide();

    if (count > 0) {
        var html = "<table class='wl-table wl-edit' id='myWordlist'>";
        html += "<tbody><tr>";
        html += "<th class='wl-col1'>" + TRANSLATIONS["mywordlist.view.th.word"] + "</th>";
        html += "<th class='wl-col3'>" + TRANSLATIONS["mywordlist.view.th.def"] + "</th>";
        html += "<th class='wl-col5 show_premium_mywordlist'>";
        if (isUserWordlist(wordlistUserId)) {
            html += TRANSLATIONS["mywordlist.view.th.del"];
        }
        html += "</th></tr>";
        for (var i = 0; i < count; i++) {
            var word = words[i];

            var link_to_word = definitionURL + word.entryId.split("__")[0] + (word.senseId != null ? "#" + word.senseId : "");
            html += "<tr>";
            html += "<td class='wl-col1'><a href='" + link_to_word + "'>" + word.headword + "</a><span class='wl-col2'>" + (word.pos != null ? TRANSLATIONS["wordlists.pos." + word.pos] : "") + "</span>"
                    + "<div class='top-g'>";

                    var soundUK = word.soundUK;

                    if (soundUK) {
                        html += "<div class='sound audio_play_button pron-uk icon-audio' valign='top' style='cursor: pointer' title='pronunciation British' ";

                        if (soundUK.toLowerCase().substring(soundUK.length - 3) == "mp3") {
                            html += " data-src-mp3='" + oldoApi._baseUrl + "media/english/uk_pron/" + soundUK + "' ";
                        } else if (soundUK.toLowerCase().substring(soundUK.length - 3) == "ogg") {
                            html += " data-src-ogg='" + oldoApi._baseUrl + "media/english/uk_pron_ogg/" + soundUK + "' ";
                        }

                        html += ">&nbsp;</div>&nbsp;";
                    }

                    soundUS = word.soundUS;

                    if (soundUS) {
                        html += "<div class='sound audio_play_button pron-us icon-audio' valign='top' style='cursor: pointer' title='pronunciation American' ";

                        if (soundUS.toLowerCase().substring(soundUS.length - 3) == "mp3") {
                            html += " data-src-mp3='" + oldoApi._baseUrl + "media/english/us_pron/" + soundUS + "' ";
                        } else if (soundUS.toLowerCase().substring(soundUS.length - 3) == "ogg") {
                            html += " data-src-ogg='" + oldoApi._baseUrl + "media/english/us_pron_ogg/" + soundUS + "' ";
                        }

                        html += ">&nbsp;</div>";
                    }

                    html+= "</div>";
            html += "</td>";
            html += "<td class='wl-col3'>" + word.definition + "</td>";
            html += isUserWordlist(wordlistUserId) ?
                "<td class='wl-col5 show_premium_mywordlist'>"
                    + "<div class='btn icon-left icon-only delete-btn'>"
                        + "<a title='"+ TRANSLATIONS["mywordlist.view.tooltip"] +"' alt='"+ TRANSLATIONS["mywordlist.view.tooltip"] +"'"
                        + "onclick='deleteWordlistEntry("+ wordlistId +","+ word.id +")'>delete word</a>"
                    + "</div>"
                + "</td>"
                : "<td></td>";
            html += "</tr>";
        }
        html += "</tbody></table>";
    } else {
        $("#testme-link").bind('click', false);
        html = "<span>"+ TRANSLATIONS["mywordlist.view.emptylist"] +"</span>";
    }
    $(html).appendTo('.wordlist-container');

    bindAudioButtons();

    // Display the score
    if(isLoggedIn) {
        $("#mywordlists-score").empty();
        var userMetadatas = jsonWordlist.userMetadatas;
        if(!userMetadatas.score){
            userMetadatas.score = 0;
        }
        var score = userMetadatas.score;
        $("#mywordlists-score").append(score + " %");
    }
};

function deleteWordlistEntry(wordListId,wordId){
    confirmPanel(TRANSLATIONS["mywordlist.view.confirm_msg"], 
        function() {
            window.oldoApi.deleteWordlistEntry(wordlistId, wordId,deleteWordlistEntryCb,deleteWordlistEntryFailureCb)
        }
    );
};
/*
 * Refresh the wordlist and scoreboard
 */
var deleteWordlistEntryCb = function(){
    oldoApi.getWordlist(wordlistId, getWordlistCb);
};

var deleteWordlistEntryFailureCb = function(response, requestOptions){
    $("#supp").hide();

    oldoApi._defaultFailureCb(response, requestOptions);
};

var focusName = function(wordListId, oldName) {
    var wordlistName = $("#wln-" + wordListId);
    var subMenu = document.getElementById("subToolMenu" + wordListId);
    subMenu.style.display = "none";
    if (wordlistName.length == 1) {
        var focuslocked = true;
        wordlistName.on("focus", function(event){
            wordlistName[0].setAttribute("contenteditable","true");
            var range = document.createRange();
            range.selectNodeContents($(this)[0]);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            event.stopPropagation();
        });
        wordlistName.on( "keypress", function(event) {
            if (event.which == 13 && !event.shiftKey) {
                event.preventDefault();
                focuslocked=false;
                window.getSelection().removeAllRanges();
                $(this).blur();
            }
        });

        wordlistName.on( "blur", function(event) {
            if(wordlistName[0].getAttribute("contenteditable") == "true"){
              wordlistName[0].setAttribute("contenteditable","false");
              renameWordlist(wordListId, this.innerHTML, oldName, wordlistName[0]);
            }

        });
        wordlistName.focus(); 
    }
};
function deleteWordlist(wordListId){
    var refresh = function() {
        location.reload();
    }
    confirmPanel(TRANSLATIONS["mywordlist.home.confirm_msg"], 
        function() {
            window.oldoApi.deleteWordlist(wordListId, refresh);
        }
    );
};
function confirmPanel(msg, callbackDelete) {
    var $content =  "<div class='dialog-ovelay'>"
                    + "<div class='dialog'><div class='dialog-msg'><p> " + msg + " </p></div>"
                    + "<footer><div class='controls'>"
                    + "<button id='deleteWordOrWordlist' class='button button-danger doAction'>" + TRANSLATIONS["mywordlist.btn.confirm"] + "</button>"
                    + "<button class='button button-default cancelAction'>" + TRANSLATIONS["mywordlist.btn.cancel"] + "</button>"
                    + "</div></footer></div></div>";
    $('body').prepend($content);
    $('.doAction').click(function () {
        $(this).parents('.dialog-ovelay').fadeOut(500, function () {
            callbackDelete();
            $(this).remove();
        });
    });
    $('.dialog-ovelay').click(function () {
        $(this).remove();
    });
};
function renameWordlist(wordListId, newName, oldName, wordlistNameDisplay){
    if (newName != oldName) {
        var refresh = function() {
            location.reload();
        }
        var failureCb = function(response, requestOptions) {
            wordlistNameDisplay.innerHTML = oldName;
            window.oldoApi._defaultFailureCb(response, requestOptions);
        }
        window.oldoApi.updateWordlist(wordListId, {"name": newName}, refresh, failureCb);    
    }
};
function displayToolMenu(obj, wordListId){

    var idToolMenu = obj.id;
    var idSubMenu = 'sub' + idToolMenu;
    var subMenu = document.getElementById(idSubMenu);
    var allSubMenu = document.getElementsByName("subToolMenu");
    var ToolButton = document.getElementById("tool-btn-" + wordListId);
    for(var i=0; i < allSubMenu.length; i++) {
        if (allSubMenu[i] != subMenu)
            allSubMenu[i].style.display = "none";
    }
    resetToolIcon();
    if(subMenu){
        if(subMenu.style.display == "block"){
            subMenu.style.display = "none";
        } else {
            subMenu.style.display = "block";
        }
    }

};
function resetToolIcon() {
    var allToolIcon = $(".tool-icon");
    for (var i=0; i < allToolIcon.length; i++){
        allToolIcon[i].style.background="url(\"../external/images/myWordlist/btn-tool.png\") no-repeat transparent";
        allToolIcon[i].style.backgroundSize="contain";
        allToolIcon[i].style.zIndex="auto";
    }
}
var displayCreateWordlist = function() {
    html = "<div class='tint_panel tint_blue'>"
           + "<h3 class='my-wordlist-titles'>" + TRANSLATIONS["mywordlist.home.create"] + "</h3>"
           + "<div class='test__form'>"
           + "<div class='test__answer'>"
           + "<input class='wl-name' type='text' onblur='this.value=(this.value==\"\") ? changeText(\"" + TRANSLATIONS["mywordlist.home.title"] + "\", this) : this.value;' onfocus='this.value=(this.value==\"" + TRANSLATIONS["mywordlist.home.title"] + "\") ? changeText(\"\", this) : this.value;' value='" + TRANSLATIONS["mywordlist.home.title"] + "' id='create_wordlist'>"
           + "</div>"
           + "<div class='test__submit'>"
           + "<input id='add-wordlist' type='submit' value='" + TRANSLATIONS["mywordlist.btn.submit"] + "' onclick='createUserWordList($(\".wl-name\").val())'>"
           + "</div>"
           + "<div class='wordlist-invalid' style='color:red; padding-left:15px; padding-top:5px;display:none;'>" + TRANSLATIONS["mywordlist.home.invalid"] + "</div>"
           + "</div>"
           + "</div>";
    $(html).appendTo('.createWordlist-container');
    $("#wait").hide();
};
function createUserWordList(newWordListName){
    $(".wordlist-invalid").hide();
    if(newWordListName && newWordListName.length > 0 && (newWordListName.indexOf('\"')>=0 || newWordListName.indexOf('\\')>=0 || newWordListName == newWordlistDefaultText)) {
        $(".wordlist-invalid").css("display", "flex");
        return false;
    }

    var successCallback = function() {
        location.reload();
    }
    window.oldoApi.createWordlist({"name":newWordListName}, successCallback);

    return true;
};