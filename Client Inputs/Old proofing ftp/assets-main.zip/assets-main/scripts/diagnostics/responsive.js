function Ads(name, hd, desktop, tablet, smartphone) {
    this.name = name;
    this.hd = hd;
    this.desktop = desktop;
    this.tablet = tablet;
    this.smartphone = smartphone;
}

function refreshSlot(callback, ads) {
    var newRes = getResolution();
    if (newRes != curRes) {
        if ((callback != null || callback != undefined) && (ads != null || ads != undefined)) {
            callback(ads, newRes);
        }
        curRes = newRes;
        googletag.pubads().refresh();
    }
}

function getResolution() {
    var res = null;
    if (window.matchMedia("(max-width: 761px)").matches)
        res = "smartphone";
    else if (window.matchMedia("(min-width: 762px) and (max-width: 928px)").matches)
        res = "tablet";
    else if (window.matchMedia("(min-width: 1220px)").matches)
        res = "hd";
    else
        res = "desktop";
    return res;
}

function displayAds(ads, newRes) {
    for (var i = 0; i < ads.length; i++) {
        var slotId = null;
        var otherSlotIds = [];

        for (var key in ads[i]) {
            if (newRes == key)
                slotId = ads[i][key];
            else
                otherSlotIds.push(ads[i][key]);
        }

        for (var j = 0; j < otherSlotIds.length; j++) {
            if (!$(otherSlotIds[j]).is(':empty'))
                $(otherSlotIds[j]).empty();
        }
        if ($(slotId).is(':empty')) {
            $(slotId).append("<div id='dfp_ad_" + ads[i].name + "'>")
            $('<script>googletag.cmd.push(function() {googletag.display("dfp_ad_' + ads[i].name + '"); });</' + 'script>').appendTo("#dfp_ad_" + ads[i].name)
        }
    }
}