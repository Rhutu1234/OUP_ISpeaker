var _FileApiService = new FileApiService();
var fileUrl = baseFileApiUrl + '/info/' + userId + '/';
var main_fileUrl = baseFileApiUrl + "/file/" + userId + "/main.json";
var answer_fileUrl = baseFileApiUrl + "/file/" + userId + "/user_ans.json";

var Scrom = function () {
    var _this = this;
    this.uploadMain = function () {
        console.log("---------fileURL-------");
        console.log(userId);
        _FileApiService.getHttp(fileUrl, function (data) {
            console.log(data);
            if (data.length != 0) {
                var controller_status = false;
                for (var i in data) {
                    var n = data[i][0].indexOf("main.json");
                    if (n != (-1)) {
                        controller_status = true;
                        break;
                    }
                }
                if (!controller_status) {
                    upload_controller();
                }
            }

        });
    }
    this.checkUserAnswer = function (index, cb) {
        _FileApiService.getHttp(fileUrl, function (data) {
            console.log(data);
            if (data.length != 0) {
                var controller_status = false;
                for (var i in data) {
                    var n = data[i][0].indexOf("data_" + index + ".json");
                    if (n != (-1)) {
                        controller_status = true;
                        break;
                    }
                }
                if (controller_status) {
                    cb(true)
                } else {
                    cb(false)
                }
            }

        });
    }
    this.getExcercisedata = function (cb) {

        console.log("--------get main.json data----------");
        _FileApiService.getJson(main_fileUrl, function (data) {
            cb(data);
        }, "jsonpCallbackFunction");
    }
    this.uploadExcercisedata = function (data, cb) {
        console.log("----upload main.json data----------");
        console.log(data);
        var json_str = 'jsonpCallbackFunction(' + JSON.stringify(data) + ');';
        _FileApiService.fileUpload(main_fileUrl, json_str, function (get_data) {

        });
    }
    this.getuserData = function (file, cb) {
        var url = baseFileApiUrl + "/file/" + userId + "/" + file + '.json';
        _FileApiService.getJson(url, function (data) {
            cb(data);
        }, "jsonpCallbackFunction");


    }


    this.updateUserData = function (file, data, cb) {

        var url = baseFileApiUrl + "/file/" + userId + "/" + file + '.json';
        console.log("url::" + url);
        console.log(data);
        var json_str = 'jsonpCallbackFunction(' + JSON.stringify(data) + ');';
        _FileApiService.fileUpload(url, json_str, function (data) {
            console.log(data);
            if (data) {

            } else {
                _this.updateUserData(file, data, cb);
            }
        });

    }
    function upload_controller() {
        asset_path = asset_path.trim();
        console.log(asset_path);
        $.getJSON(asset_path + 'db/main.json', function (main) {
            console.log(main);
            var json_str = 'jsonpCallbackFunction(' + JSON.stringify(main) + ');';
            _FileApiService.fileUpload(main_fileUrl, json_str, function (data) {
                console.log(data);
                if (data) {

                } else {
                    upload_controller();
                }
            });
        });
    }
    var i = 0;
    this.deleteMain = function () {

        //_FileApiService.httpDel(main_fileUrl, function (data) {
        //console.log(baseFileApiUrl + "/file/" + userId + "/data_" + (i) + ".json");
        _FileApiService.httpDel(baseFileApiUrl + "/file/" + userId + "/data_" + (i) + ".json", function (data) {
            if (i < 28) {
                i++;
                _this.deleteMain();
            } else {
                _FileApiService.httpDel(main_fileUrl, function (data) {
                    $('.mloader').hide();
                    alert("All Files Deleted");
                    location.href = location.href;
                });

            }
        });

        // })



    }



}