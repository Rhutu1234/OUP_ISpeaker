var wordlistUtils = new WordlistUtils();

function WordlistUtils() {
}

WordlistUtils.prototype.displayCreateWordlistForm = function() {
    html = "<div class='tint_panel tint_blue'>"
           + "<h3 class='my-wordlist-titles'>" + mwTranslations.create + "</h3>"
           + "<div class='test__form'>"
           + "<form method='POST' action='' id='add-wordlist' onsubmit='myScoreBoard.createUserWordlist($(\".wl-name\").val(), \"home\"); $(\"#create_wordlist\").val(\"\"); $(\"#create_wordlist\").blur(); return false;'>"
           + "<div class='test__answer'>"
           + "<input class='wl-name' type='text' onblur='this.value=(this.value==\"\") ? changeText(\"" + mwTranslations.title + "\", this) : this.value;' onfocus='this.value=(this.value==\"" + mwTranslations.title + "\") ? changeText(\"\", this) : this.value;' value='" + mwTranslations.title + "' id='create_wordlist'>"
           + "</div>"
           + "<div class='test__submit'>"
           + "<input type='submit' value='Submit'>"
           + "</div>"
           + "<div class='wordlist-exist' style='color:red; padding-left:15px; padding-top:5px;display:none;'>" + mwTranslations.exist + "</div>"
           + "<div class='wordlist-invalid' style='color:red; padding-left:15px; padding-top:5px;display:none;'>" + mwTranslations.invalid + "</div>"
           + "</form>"
           + "</div>"
           + "</div>";
    $(html).appendTo('.createWordlist-container');
};

WordlistUtils.prototype.displayScoreBoard = function(myScoreBoard) {
    $("#wordlistnb").empty();
    $("#wordlistnb").append(myScoreBoard.getWordlistsCount());
    $(".scoreboard-container").empty();
    var wordlists = myScoreBoard.wordlists;
    var system_row = false;

    html = "<table id='myScoreboard' class='wl-table wl-home'>";
    html += "<tr>";
    html += "<th class='wl-col1'>" + mwTranslations.th1 + "</th>";
    // html += "<th class='wl-col2'>" + mwTranslations.th2 + "</th>";
    html += "<th class='wl-col2'>" + mwTranslations.th3 + "</th>";
    html += "<th class='wl-col3 show_premium'>" + mwTranslations.th4 + "</th>";
    html += "<th class='wl-col4'>" + mwTranslations.th5 + "</th>";
    html += "<th class='wl-col5 show_premium'>" + mwTranslations.th6 + "</th></tr>";
    for ( var i = 0; i < wordlists.length; i++) {
        if (wordlists[i].disabled != "true") {
            if (wordlists[i].type == "system" && !system_row) {
                html += "<tr><td colspan='5' class='wl-sub-head'>" + mwTranslations.systwl_label + "</td></tr>";
                system_row = true;
            }
            html += "<tr>";
            html += "<td class='wl-col1' name='title'>";
            html += "<a href='view' onclick='sessionStorage.setItem(\"id\",\"" + wordlists[i].id
                    + "\"); sessionStorage.setItem(\"type\",\"" + wordlists[i].type + "\")'>" + wordlists[i].name
                    + "</a>";
            html += "</td>";
            html += "<td class='wl-col2' name='wordnb'>" + wordlists[i].wordnb + "</td>";
            html += "<td class='wl-col3 show_premium' name='score'>" + wordlists[i].score + " %</td>";
            html += "<td class='wl-col4' name='test'>";
            html += "<div class='btn icon-left test-btn'>";
            html += "<a title='" + mwTranslations.tooltip1 + "' alt='" + mwTranslations.tooltip1
                    + "' href='testme' onclick='sessionStorage.setItem(\"id\",\"" + wordlists[i].id
                    + "\"); sessionStorage.setItem(\"type\",\"" + wordlists[i].type
                    + "\")'>Take the test</a></div></td>";
            html += (wordlists[i].type != "system") ? "<td class='wl-col5 show_premium_mywordlist' name='delete'><div class='btn icon-left icon-only delete-btn'><a title = '"
                    + mwTranslations.tooltip2
                    + "' alt = '"
                    + mwTranslations.tooltip2
                    + "' href='#myScoreboard' onclick='var response = confirm(\""
                    + mwTranslations.confirm_msg
                    + "\");if(response){myScoreBoard.disableWordlist(\""
                    + wordlists[i].id
                    + "\",\""
                    + wordlists[i].type + "\")}'>Delete wordlist</a></div></td>"
                    : "<td class='hide-delete-icon'></td>";
            html += "</tr>";
        }
    }
    html += '</table>';
    $(html).appendTo('.scoreboard-container');

    // loop on the table to disable the take a test button for wordlists which have 0 words in it
    $("#myScoreboard > tbody > tr").each(function() {
        var currentTd = $(this).find('td[name=wordnb]');
        var nbWords = currentTd.html();
        if (nbWords == 0) {
            $(this).find("div.test-btn > a").bind("click", function() {
                alert("You cannot take a test with an empty wordlist!");
                return false;
            });
        }
    });

    return;
};

WordlistUtils.prototype.displayWordlist = function(myWordlist, isLoggedIn) {
    var myWordlist_count = myWordlist.getWordsCount();
    $("#myWordlist").remove();
    $("#supp").hide();
    $(".nbWords").empty();
    $(".nbWords").append(myWordlist_count);
    $("#wordlist-name").empty();
    $("#wordlist-name").append(myWordlist.name);
    if (myWordlist_count > 0) {
        html = "<table class='wl-table wl-edit' id='myWordlist'>";
        html += "<tbody><tr>";
        html += "<th class='wl-col1'>" + mwTranslations.th1 + "</th>";
        html += "<th class='wl-col3'>" + mwTranslations.th2 + "</th>";
        html += "<th class='wl-col5 show_premium'>";
        if ("user" == sessionStorage.getItem("type"))
            html += mwTranslations.th3;
        html += "</th></tr>";
        for ( var i = 0; i < myWordlist.words.length; i++) {
            if (myWordlist.words[i].disabled != "true") {
                var link_to_word = definitionURL + myWordlist.words[i].id.split("__")[0];
                html += '<tr>';
                html += "<td class='wl-col1'><a href='" + link_to_word + "'>" + myWordlist.words[i].hwd
                        + "</a><span class='wl-col2'>" + myWordlist.words[i].pos + "</span></td>";
                html += "<td class='wl-col3'>" + myWordlist.words[i].definition + "</td>";
                html += ("user" == sessionStorage.getItem("type")) ? "<td class='wl-col5 show_premium_mywordlist'><div class=\"btn icon-left icon-only delete-btn\"><a title=\""
                        + mwTranslations.tooltip
                        + "\" alt=\""
                        + mwTranslations.tooltip
                        + "\" href=\"#myWordlist\" onclick='var response = confirm(\""
                        + mwTranslations.confirm_msg
                        + "\");if(response){ $(\"#supp\").show(); myWordlist.deleteWord(\""
                        + myWordlist.words[i].dictCode
                        + "\",\""
                        + myWordlist.words[i].id
                        + "\", " + isLoggedIn + "), myWordlist.save(_wordlist,\"edit\")}'>delete word</a></div></td>"
                        : "<td></td>";
                html += "</tr>";
            }
        }
        html += "</tbody></table>";
    } else {
        $("#testme-link").bind('click', false);
        html = "<span>" + emptylist + "</span>";
    }
    $(html).appendTo('.wordlist-container');

    // load the scoreboard and get the score of the current wordlist
    if (isLoggedIn) {
        var jsonFile = baseFileApiUrl + "/file/myscoreboard.json";
        $.ajax({
            type : 'GET',
            url : jsonFile,
            dataType : 'jsonp',
            jsonp : false,
            jsonpCallback : jsonpCall,
            crossDomain : true,
            success : function(wordlists) {
                for ( var i = 0; i < wordlists.length; i++)
                    if (wordlists[i].id == sessionStorage.id && wordlists[i].type == sessionStorage.type) {
                        var score = wordlists[i].score;
                        $("#mywordlists-score").empty();
                        $("#mywordlists-score").append(score + " %");
                        _wordlist = wordlists[i];
                    }
            },
            error : function() {
                //console.log('WordlistUtils.prototype.displayWordlist: ajax error');
            }
        });
    }
};

WordlistUtils.prototype.saveJsonFile = function(jsonFile, destUrl) {
    var fd = new FormData();
    fd.append("file", jsonFile);
    fd.append("redirect", false);
    //console.log("WordlistUtils.prototype.saveJsonFile: " + fd);

    var token = $("meta[name='_csrf']").attr("content");
    var header = $("meta[name='_csrf_header']").attr("content");

    $.ajax({
        url : destUrl,
        type : 'POST',
        method : 'PUT',
        async : false,
        cache : false,
        data : fd,
        // Options to tell jQuery not to process data or worry about content-type.
        cache : false,
        contentType : false,
        processData : false,
        crossDomain : true,
        beforeSend: function(xhr){
            xhr.setRequestHeader(header, token);
        },
        success : function() {
        },
        complete : function() {
        },
        error : function(res) {
            //console.log("WordlistUtils.prototype.saveJsonFile - Error: " + res);
        }
    });
};

WordlistUtils.prototype.displayScoreBoardInSelectTag = function(myScoreboard, selectTagId) {
    var html = '<option value="">Please select</option>';
    for ( var i = 0; i < myScoreboard.wordlists.length; i++)
        if (myScoreboard.wordlists[i].disabled != "true" && myScoreboard.wordlists[i].type != "system")
            html += '<option value="' + myScoreboard.wordlists[i].id + '">' + myScoreboard.wordlists[i].name
                    + '</option>';
    html += '<option value="create_wordlist" id="create" class="show_premium_mywordlist">Create ...</option>';
    $(html).appendTo(selectTagId);
};
